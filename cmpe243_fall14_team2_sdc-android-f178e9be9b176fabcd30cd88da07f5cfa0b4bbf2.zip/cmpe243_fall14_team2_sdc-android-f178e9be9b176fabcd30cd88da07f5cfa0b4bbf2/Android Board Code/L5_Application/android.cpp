/*
 * master.cpp
 *
 *  Created on: Oct 20, 2014
 *      Author: Roady
 */

#include "android.hpp"

static uint8_t sensor_data[8] = {0};
static uint8_t motor_data[8] = {0};

canDataSendTask::canDataSendTask(uint16_t periodMs, uint8_t priority,const char* taskName,uint32_t stackSize) :
                scheduler_task(taskName,stackSize, priority),
                mTaskPeriodMs(periodMs),mCanDatasize(0)
            {
                setRunDuration(periodMs);
            }


bool canDataSendTask::run(void *p)
{
    if(SW.getSwitch(3)){
    puts("Publish Dummy Data by calling PublishSubscribedMessageData\n");

     memset(&mCanData, 0, sizeof(mCanData));

     motor_direction_t dir = motor_dir_0D;
     if(sensor_data[0]<=10)
         dir=motor_dir_l25D;

     mCanData[motor_dataIndex_state] = motor_state_update;
     mCanData[motor_dataIndex_direction] = dir;
     mCanData[motor_dataIndex_speed] = motor_speed_f30;
     mCanData[motor_dataIndex_distance] = 100;
     mCanDatasize=4;

     canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_master_publish_setNewMotorData),mCanData,mCanDatasize);


     puts("Publish Dummy Data to display\n");

      memset(&mCanData, 0, sizeof(mCanData));
      mCanData[0] = 'a';
      mCanData[1] = 'b';
      mCanData[2] = 'c';
      mCanData[3] = 'd';
      mCanDatasize=4;

      canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_inputOutput_publish_getDisplayData),mCanData,mCanDatasize);
    }
    else if(SW.getSwitch(1)){

    puts("Sending CAN subsription message to motor\n");


     memset(&mCanMsg, 0, sizeof(mCanMsg));

     memset(&mCanData, 0, sizeof(mCanData));
     mCanData[0]=50;
     // 0the member of data array has subscription message frequency
     mCanDatasize=1;

     mCanMsg=CreateCANMessage(0,0x0525040B,1,1,(const char*)mCanData);
     CAN_tx(can1, &mCanMsg, 0);


     puts("Sending CAN subsription message to Sensor\n");


      memset(&mCanMsg, 0, sizeof(mCanMsg));

      memset(&mCanData, 0, sizeof(mCanData));
      mCanData[0]=50;
      // 0the member of data array has subscription message frequency
      mCanDatasize=1;
      //mid_geo_subsp_data

      mCanMsg=CreateCANMessage(0,0x0535040A,1,1,(const char*)mCanData);
      CAN_tx(can1, &mCanMsg, 0);
     }
    else if(SW.getSwitch(2))
    {

        puts("Sending CAN subsription message to Compass\n");


         memset(&mCanMsg, 0, sizeof(mCanMsg));

         memset(&mCanData, 0, sizeof(mCanData));
         mCanData[0]=50;
         // 0the member of data array has subscription message frequency
         mCanDatasize=1;
         //mid_geo_subsp_data
         mCanMsg=CreateCANMessage(0,0x0515040C,1,1,(const char*)mCanData);
         CAN_tx(can1, &mCanMsg, 0);
    }

     return true;
    }




static void  subscription_add(can_msg_t* msg)
{
    if(msg==NULL)return;

    uint8_t srcId = ((*msg).msg_id>>CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (*msg).msg_id & 0xfffU | 0x00000100;//changing subscription message to subscribed message

#ifdef DEBUG_SUBSCRIPTION_TASK
    printf("message id is: %x,src id is: %x\n ",(*msg).msg_id, srcId);
    printf("subscription Hz : %x",(*msg).data.bytes[0]);
    printf("Hz -> enum : %x",convertHzTomsdRateEnum((*msg).data.bytes[0]));
#endif

    msgRate_t msgRate=convertHzTomsdRateEnum((*msg).data.bytes[0]);//msgRate1Hz;
    canSubscribedMsgTask::addSubscribedMsg(msgRate,srcId,msgId, msg);

}


canMsgRecieveTask::canMsgRecieveTask(uint16_t periodMs,uint8_t priority,const char* taskName,const uint32_t stackSize) :
            scheduler_task(taskName,stackSize, priority),
            mTaskPeriodMs(periodMs)
    {
            setRunDuration(periodMs);
    }


bool canMsgRecieveTask::run(void *p)
{
    if(CAN_rx(can1,&mmsg,portMAX_DELAY))
    {
        puts("MASTER: CAN subscription message got\n");

        can_msg_t* msg= new can_msg_t;

        if(msg==NULL)
            return false;

        switch(mmsg.msg_id&(0xfffU))
        {
            case 0x400 ... 0x4FF:
#ifdef DEBUG_SUBSCRIPTION_TASK
            puts("MASTER: CAN subscription message got");
            printf(" with message id:%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
            memset(msg, 0, sizeof(msg));
            *msg=mmsg;
            subscription_add(msg);

            break;

            case 0x500 ... 0x5FF:
#ifdef DEBUG_SUBSCRIPTION_TASK
            puts("MASTER: CAN subscribed message got");
           // printf(" with message id:%x, %x and message data: %x,%x,%x,%x,%x,%x,%x,%x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU),mmsg.data.bytes[0],mmsg.data.bytes[1],mmsg.data.bytes[2],mmsg.data.bytes[3],mmsg.data.bytes[4],mmsg.data.bytes[5],mmsg.data.bytes[6],mmsg.data.bytes[7]);
            sensor_data[0]=mmsg.data.bytes[0];

            #endif
            break;

            default:
                delete msg;
#ifdef DEBUG_SUBSCRIPTION_TASK
                printf("MASTER: Unexpected message id got(master):%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
                break;
        };

    }

    return true;
}
