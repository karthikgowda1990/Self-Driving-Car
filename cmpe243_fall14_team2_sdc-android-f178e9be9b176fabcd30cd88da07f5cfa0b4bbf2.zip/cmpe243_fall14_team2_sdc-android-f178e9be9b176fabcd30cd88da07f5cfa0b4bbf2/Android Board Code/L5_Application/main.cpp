#include "uart2.hpp"       // Board sensors
#include "io.hpp"
#include <string.h>
#include "utilities.h"  // delay_ms()
#include<stdio.h>
#include<string.h>
#include "boardIds.hpp"
#include "android.hpp"

void logCANMessageTransmit()
{
    static uint32_t canPreviousMsgCount = 0;
    static bool oldLEDValue = false;
    uint32_t msgCount = GetCanMsgCount();

    if (canPreviousMsgCount != msgCount)
    {
        if (oldLEDValue == false)
            LE.on(3);
            else
            LE.off(3);

            oldLEDValue = !oldLEDValue;

            canPreviousMsgCount=msgCount;
        }
    }

char uart1_pchar(char out)
{
    LPC_UART2->THR = out;
    while (!(LPC_UART2->LSR & (1 << 6)))
        ;
    return 1;
}

double stof(const char* s)
{
    double rez = 0, fact = 1;
    if (*s == '-')
    {
        s++;
        fact = -1;
    };
    for (int point_seen = 0; *s; s++)
    {
        if (*s == '.')
        {
            point_seen = 1;
            continue;
        };
        int d = *s - '0';
        if (d >= 0 && d <= 9)
        {
            if (point_seen)
                fact /= 10.0f;
            rez = rez * 10.0f + (double) d;
        };
        printf("Internal is %lf\n", rez);
    };
    return rez * fact;
}
;
char uart1_gchar(char &in)
{
    while (!(LPC_UART2->LSR & (1 << 0)))
        ;
    in = LPC_UART2->RBR;

    return 1;
}
void can_initialize()
{

    InitializeCan();
    SetCANFilter(ANDROID_CAN29_EXGRP1START, ANDROID_CAN29_EXGRP1END);
    //scheduler_add_task(new terminalTask(PRIORITY_HIGH));
    addSubscriptionTasks(PRIORITY_MEDIUM);
    scheduler_add_task(
            new canDataSendTask(20, PRIORITY_MEDIUM, "canMsgSendTask",
                    3 * 512));

}
#define SWITCH_NO 1

void getCordinates(float *lat, float *longitude)
{

}

int getValue(double &retVal)
{
    static int i = 0;
//    char s[4][32]={"37.335235289016296",
//                    "-121.88122753053804",
//                   "38.335235289016296",
//                    "-120.88122753053804"};
    char s[4][32] =
    { "37.336523", "-121.881857", "37.336224", "-120.881830" };

    if (i <= 3)
    {
        retVal = atof(s[i++]);
        return 1;
    }
    else
    {
        i = 0;
        return 0;
    }
}
int getValueFromAndroid(char *buffer, double &retVal,int &stringIndex)
{
    //printf("In");
    int index = 0;
    char C;
    char cordinateValue[32];
  //  C=buffer[stringIndex];
    //if(stin)
    if(buffer[stringIndex]=='p')
        stringIndex++;
    if (buffer[stringIndex] == 'a')
    {
        return 0;
    }
    /// Getting Entire Cordinate Value
    while (buffer[stringIndex] != 'p')
    {
 //       printf("%c",buffer[stringIndex]);
        cordinateValue[index++] = buffer[stringIndex++];
    };
    cordinateValue[index] = '\0';
    printf("Cordinate is %s\n",cordinateValue);
    stringIndex++;
    retVal = atof(cordinateValue);
    //printf("out");
    return 1;
}
#define HARDCODED 1
int main(void)
{

    can_initialize();

//    scheduler_start();

//    subscribedMsg_t subsMsg;
//    const can_t canbusNum = can1; /* CAN Bus to use */
//    const uint32_t timeoutMs = 50; /* Some reasonable time */
    can_msg_t msg;
    uint8_t mCanData[8];
    uint8_t dataSize = 0;
    ////////////////
    LPC_SC->PCONP |= (1 << 24);
    LPC_SC->PCLKSEL1 &= ~(3 << 16);
    LPC_SC->PCLKSEL1 |= (1 << 16);

    LPC_PINCON->PINSEL4 &= ~(3 << 16);
    LPC_PINCON->PINSEL4 |= (1 << 17);
    LPC_PINCON->PINSEL4 &= ~(3 << 18);
    LPC_PINCON->PINSEL4 |= (1 << 19);

    LPC_UART2->LCR |= (1 << 7);
    uint32_t d = (sys_get_cpu_clock()) / ((16 * 9600) + 0.5);
    LPC_UART2->DLM = (d >> 8);
    LPC_UART2->DLL = d;
    LPC_UART2->LCR &= ~(1 << 7);
    LPC_UART2->LCR |= (3 << 0);

    LPC_PINCON->PINSEL0 &= ~(3 << 0);
    LPC_GPIO0->FIODIR |= (1 << 0);
    LPC_GPIO0->FIOSET = 0x01;

    char *a = "AT+STATE?\r\np";
    char m[20];
    int i = 0;
    float latitiude, longitude;
    char InputCordinates[32] = "-121.88122753053804";
    char C ;//= a[0];
    int isLatitude = 1;
    Switches &sw = Switches::getInstance();
    int isdone = 0;
    double value = 0.0;

    if (true != sw.init())
    {
        printf("ERROR: switch init() failed\n");
        return -1;
    }
    int counter = 0;
    int isSwitchFlag = 0;
    char buffer[4096];
    int cIndex=0;
    int stringIndex=0;;
//    while(1){
//        uart1_gchar(C);
//        printf("%c\n", C);
//    }
//        buffer[cIndex++]=C;
//        if(C=='a'){
//            buffer[cIndex]='\0';
//            printf("%s\n",buffer);
//            //braak;
//        }
//    }
    while (1)
    {

#if 0
        if (sw.getSwitch(SWITCH_NO) == true) // && isdone==0)
        {
            while (getValue (value))
            {
                LD.setNumber(3);
                memset(&msg, 0, sizeof(msg));
                memset(&mCanData, 0, sizeof(mCanData));
                memcpy(mCanData, &value, 8);
                dataSize = 8;
                if (isLatitude == 1)
                {
                    printf("Sending Latitude Data now  %lf\n", value);
//                    for (int w = 0; w < 8; w++)
//                    {
//                        printf("lat data %d:%x\n", w, mCanData[w]);
//                    }
                    msg = CreateCANMessage(counter, 0x05155353, 1, dataSize,
                            (const char *) mCanData);
                    counter++;
                    isLatitude = 0;
                }
                else
                {
                    printf("Sending Longitude Data now %lf\n", value);
                    for (int w = 0; w < 8; w++)
                    {
                        printf("long data %d:%x\n", w, mCanData[w]);
                    }
                    msg = CreateCANMessage(counter, 0x05155354, 1, dataSize,
                            (const char *) mCanData);
                    counter++;
                    isLatitude = 1;
                }
                CAN_tx(can1, &msg, 0);
                logCANMessageTransmit();
                delay_ms(500);
            }

            memset(&msg, 0, sizeof(msg));
            //memset(&mCanData, 0, sizeof(mCanData));
            printf("Sending Data\n");
            dataSize = 0;
            //value = atof(InputCordinates);
            msg = CreateCANMessage(counter, 0x05155355, 1, dataSize,
                    (const char*) NULL);
            counter++;
            CAN_tx(can1, &msg, 0);
            logCANMessageTransmit();
            delay_ms(500);
            memset(&msg, 0, sizeof(msg));
            memset(&mCanData, 0, sizeof(mCanData));
            printf("Sending start to Master\n");
            LD.setNumber(1);

            msg = CreateCANMessage(counter, 0x05055350, 1, dataSize,
                    (const char*) mCanData);
            CAN_tx(can1, &msg, 0);
            counter++;
            logCANMessageTransmit();
            delay_ms(500);
            continue;
        }
#endif
      // continue;




        uart1_gchar(C);
       // printf("%c\n", C);
        if (C == 'a')
        {
            LD.setNumber(1);
            /// Sending start signal to Master
            memset(&msg, 0, sizeof(msg));
            memset(&mCanData, 0, sizeof(mCanData));
            printf("Sending Start Signal to Master\n");
            dataSize = 0;
            msg = CreateCANMessage(0, 0x05055350, 1, dataSize,
                    (const char*) mCanData);
            printf("Sending data of %x\n",mCanData[0]);
            CAN_tx(can1, &msg, 0);
            logCANMessageTransmit();
            delay_ms(500);

        }
        else if (C == 'z')
        {
            LD.setNumber(0);
            /// Sending STOP Signal to motor
            memset(&msg, 0, sizeof(msg));
            memset(&mCanData, 0, sizeof(mCanData));
            dataSize = 0;
            printf("Sending Stop Signal to Master\n");
            msg = CreateCANMessage(0, 0x05055351, 1, dataSize,
                    (const char*) mCanData);
            printf("Sending data of %x\n",mCanData[0]);
            CAN_tx(can1, &msg, 0);
            logCANMessageTransmit();
            delay_ms(500);

        }
        else if (C == 'p')
        {
            while(1){
                   uart1_gchar(C);
                   //printf("%c\n", C);
                   buffer[cIndex++]=C;
                   if(C=='a'){
                       buffer[cIndex]='\0';
                       printf("%s\n",buffer);
                       break;
                   }
               }
            stringIndex=0;
            while (getValueFromAndroid(buffer,value,stringIndex))
            {
                LD.setNumber(3);
                memset(&msg, 0, sizeof(msg));
                memset(&mCanData, 0, sizeof(mCanData));
                memcpy(mCanData, &value, 8);
                dataSize = 8;
                if (isLatitude == 1)
                {
                    printf("Sending Latitude Data now  %lf\n", value);
//                    for (int w = 0; w < 8; w++)
//                    {
//                        printf("lat data %d:%x\n", w, mCanData[w]);
//                    }
                    msg = CreateCANMessage(counter, 0x05155353, 1, dataSize,
                            (const char *) mCanData);
                    counter++;
                    isLatitude = 0;
                }
                else
                {
                    printf("Sending Longitude Data now %lf\n", value);
                    for (int w = 0; w < 8; w++)
                    {
//                        printf("long data %d:%x\n", w, mCanData[w]);
                    }
                    msg = CreateCANMessage(counter, 0x05155354, 1, dataSize,
                            (const char *) mCanData);
                    counter++;
                    isLatitude = 1;

                }
                //printf("g\n");
                printf("Sending data of %x\n",mCanData[0]);
                CAN_tx(can1, &msg, 0);
                logCANMessageTransmit();
                delay_ms(500);
            }

            memset(&msg, 0, sizeof(msg));
            //memset(&mCanData, 0, sizeof(mCanData));
            printf("Sending End of Message to GPS\n");
            dataSize = 0;
            //value = atof(InputCordinates);
            msg = CreateCANMessage(counter, 0x05155355, 1, dataSize,
                    (const char*) NULL);
            counter++;
            printf("Sending data of %x\n",mCanData[0]);
            CAN_tx(can1, &msg, 0);
            logCANMessageTransmit();
            delay_ms(500);
            memset(&msg, 0, sizeof(msg));
            memset(&mCanData, 0, sizeof(mCanData));
            LD.setNumber(1);
            printf("Sending Start Signal to Master\n");
            msg = CreateCANMessage(counter, 0x05055350, 1, dataSize,
                    (const char*) mCanData);
            printf("Sending data of %x\n",mCanData[0]);
            CAN_tx(can1, &msg, 0);
            counter++;
            logCANMessageTransmit();
            delay_ms(500);
        }
        else
        {
            printf(":%c\n",C);
        }
        logCANMessageTransmit();
        delay_ms(500);
    }
    return 0;
}
#if 0
while (1)
{
    int isLatitude = 1;
    if (sw.getSwitch(SWITCH_NO) == true) // && isdone==0)
    {
        isdone = 1;
        double value = 0.0;
        while (getValue(value))
        {
            memset(&msg, 0, sizeof(msg));
            memset(&mCanData, 0, sizeof(mCanData));
            memcpy(mCanData, &value, 8);
            //value = atof(InputCordinates);
            dataSize = 8;
            if (isLatitude == 1)
            {
                printf("Sending Latitude Data now  %lf\n", value);
                for (int w = 0; w < 8; w++)
                {
                    printf("lat data %d:%x\n", w, mCanData[w]);
                }
                msg = CreateCANMessage(counter, 0x05155353, 1, dataSize,
                        (const char *) mCanData);
                counter++;
                isLatitude = 0;
            }
            else
            {
                printf("Sending Longitude Data now %lf\n", value);
                for (int w = 0; w < 8; w++)
                {
                    printf("long data %d:%x\n", w, mCanData[w]);
                }
                msg = CreateCANMessage(counter, 0x05155354, 1, dataSize,
                        (const char *) mCanData);
                counter++;
                isLatitude = 1;
            }
            CAN_tx(can1, &msg, 0);
            logCANMessageTransmit();
            delay_ms(500);

        }

        memset(&msg, 0, sizeof(msg));
        //memset(&mCanData, 0, sizeof(mCanData));
        printf("Sending Data\n");
        dataSize = 0;
        //value = atof(InputCordinates);
        msg = CreateCANMessage(counter, 0x05155355, 1, dataSize,
                (const char*) NULL);
        counter++;
        CAN_tx(can1, &msg, 0);
        logCANMessageTransmit();
        delay_ms(500);
        memset(&msg, 0, sizeof(msg));
        memset(&mCanData, 0, sizeof(mCanData));
        printf("Sending Data\n");
        msg = CreateCANMessage(counter, 0x05055350, 1, dataSize,
                (const char*) mCanData);
        CAN_tx(can1, &msg, 0);
        counter++;
        logCANMessageTransmit();
        delay_ms(500);

    }

}
return 0;
}
#endif

#if 0
//        double a = atof(InputCordinates);
char *s = &(InputCordinates[0]);
double rez = 0, fact = 1;
if (*s == '-')
{
s++;
fact = -1;
};
for (int point_seen = 0; *s; s++)
{
if (*s == '.')
{
    point_seen = 1;
    continue;
};
int d = *s - '0';
if (d >= 0 && d <= 9)
{
    if (point_seen) fact /= 10.0f;
    rez = rez * 10.0f + (double)d;
};
printf("Internal is %lf\n",rez);
};
printf("Huzefa Value is %lf\n",rez*fact);
isdone=1;
}

}

//        if (sw.getSwitch(SWITCH_NO) == true)
//        {
//            memset(&msg, 0, sizeof(msg));
//            memset(&mCanData, 0, sizeof(mCanData));
//            printf("Sending Data\n");
//            msg = CreateCANMessage(0, 0x05055350, 1, dataSize,
//                    (const char*) mCanData);
//            CAN_tx(can1, &msg, 0);
//
//        }else{
//
//        }
//        continue;

}
#endif
#if 0
uart1_gchar(C);
printf("%c\n", C);
if (C == '1')
{
memset(&msg, 0, sizeof(msg));
memset(&mCanData, 0, sizeof(mCanData));
printf("Sending Data\n");
msg = CreateCANMessage(0, 0x05055350, 1, dataSize,
(const char*) mCanData);
CAN_tx(can1, &msg, 0);
}
else if (C == '3')
{
memset(&msg, 0, sizeof(msg));
memset(&mCanData, 0, sizeof(mCanData));
msg = CreateCANMessage(0, 0x05055351, 1, dataSize,
(const char*) mCanData);
CAN_tx(can1, &msg, 0);
}
else if(C=='g')
{
memset(&msg, 0, sizeof(msg));
memset(&mCanData, 0, sizeof(mCanData));
getCordinates(&latitiude,&longitude);
msg = CreateCANMessage(0, 0x05055351, 1, dataSize,
(const char*) mCanData);
 //CAN_tx(can1, &msg, 0);
 // CAN_rx()
}
logCANMessageTransmit();

delay_ms(500);

}
return -1;
}
#endif
