/** Automatically generated file. DO NOT MODIFY */
package siddhata.patil.googlemapsandroidapiv2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}