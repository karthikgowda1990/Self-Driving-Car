/** Automatically generated file. DO NOT MODIFY */
package siddhata.patil.sdc243;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}