package siddhata.patil.sdc243;
enum BTCMsgType {
Null,OnConnect,OnMessage,OnClose,OnError
} 
public class BluetoothClientMsg {
BTCMsgType msgType=BTCMsgType.Null;
BluetoothClient client = null;
byte []data;
int dataL=0;
String str = null;

BluetoothClientMsg()
{
this(20);
}
BluetoothClientMsg(int bufferSize)
{
data=new byte[bufferSize];
}
}
