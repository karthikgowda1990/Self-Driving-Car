/*
 * Done by Siddhata Patil , Mohammed Raashid and Huzefa Siyamwala
 */

package siddhata.patil.sdc243;

import android.support.v7.app.ActionBarActivity;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.os.Build;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View.OnClickListener;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends ActionBarActivity implements
		OnMarkerClickListener, OnMapLongClickListener {

	static final LatLng SANJOSE = new LatLng(37.3353, -121.8813);
	static final LatLng AUSTIN = new LatLng(30.2500, -97.7500);
	GoogleMap map;
	Marker sanjose, austin;
	BluetoothClient BluC;
	String s = "37.336523";
	String t = "-121.881857";
	Button button;
	Button button1;

	@SuppressLint("NewApi")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// ip = (EditText) findViewById(R.id.editText1);
		// ip.setText(savedIP);
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();
		// map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
		// map.setMapType(GoogleMap.MAP_TYPE_NONE);
		map.setOnMarkerClickListener(this);
		map.setOnMapLongClickListener(this);
		map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
		// map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
		// map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
		map.setPadding(5, 5, 5, 5);

		if (map != null) {
			sanjose = map.addMarker(new MarkerOptions().position(SANJOSE)
					.title("SANJOSE").snippet("SJSU is Best!").draggable(true)
					.alpha(0.5f).rotation(0).flat(true));

			austin = map.addMarker(new MarkerOptions()
					.position(AUSTIN)
					.title("Austin")
					.snippet("Go Team2 !!!")
					.icon(BitmapDescriptorFactory
							.fromResource(R.drawable.ic_launcher)));
		}
		map.moveCamera(CameraUpdateFactory.newLatLngZoom(SANJOSE, 15));
		// Zoom in, animating the camera.
		map.animateCamera(CameraUpdateFactory.zoomTo(10), 2000, null);
		try {
			BluC = new BluetoothClient(handler, "ANDROBOT");
			BluC.start();
			/*
			 * BluC.outS.write("37.336523p\r".getBytes());
			 * BluC.outS.write("-121.881857p\r".getBytes());
			 * BluC.outS.write("37.3366224p\r".getBytes());
			 * BluC.outS.write("-120.881830p\r".getBytes());
			 * 
			 * BluC.outS.write("p\r".getBytes());
			 * 
			 * /*BluC.outS.write("34.456312\r".getBytes());
			 * BluC.outS.write(s.getBytes());
			 * 
			 * BluC.outS.write(t.getBytes());
			 * 
			 * /*BluC.outS.write("p".getBytes()); BluC.outS.write(t.getBytes());
			 * BluC.outS.write("p".getBytes()); BluC.outS.flush();
			 */

			BluC.outS.write("p".getBytes());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ie) {
				// Handle exception
			}
			/*BluC.outS.write(s.getBytes());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ie) {
				// Handle exception
			}
			BluC.outS.write("p".getBytes());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ie) {
				// Handle exception
			}
			BluC.outS.write(t.getBytes());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ie) {
				// Handle exception
			}
			BluC.outS.flush();
			BluC.outS.write("p".getBytes());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ie) {
				// Handle exception
			}
*/
			BluC.outS.flush();

			Log.v("Bluetooth Init", " OK");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			Log.v("Bluetooth Init", " XXX");
		}
		addListenerOnButton();
		addListenerOnButton1();
	}
	
	 

	private void addListenerOnButton1() {
		button1 = (Button) findViewById(R.id.stop);
		 
		button1.setOnClickListener(new OnClickListener() {
 
			@Override
			public void onClick(View arg0) {
				 try{
						BluC.outS.write("z".getBytes());
				    	
				    }catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				    }
			 
			}
 
		});
	}



	private void addListenerOnButton() {

		button = (Button) findViewById(R.id.start);
 
		button.setOnClickListener(new OnClickListener() {
 
			@Override
			public void onClick(View arg0) {
				 try{
						BluC.outS.write("a".getBytes());
				    	
				    }catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				    }
			 
			}
 
		});
	}
 
	@Override
	public boolean onMarkerClick(Marker marker) {
	  
	    if (marker.equals(SANJOSE)) {

	    }

	    return false;
	}

	@Override
	public void onMapLongClick(LatLng point) {

	    AlertDialog.Builder setPasswordDialog = new AlertDialog.Builder(this);
	    setPasswordDialog.setTitle("243SDC_Team 2");
	    setPasswordDialog.setMessage("Coordinates for the car:"
	            + String.valueOf(point.latitude) + " , "
	            + String.valueOf(point.longitude));
	    setPasswordDialog.show();
	    s = String.valueOf(point.latitude);
	    t = String.valueOf(point.longitude);
	    try{
			BluC.outS.write("p".getBytes());
	    	BluC.outS.write(s.getBytes());
	    	BluC.outS.write("p".getBytes());
	    	BluC.outS.write(t.getBytes());
	    }catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			Log.v("Bluetooth Send failed", " XXX");
		}
	    
	}

	
	final Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);

			if (msg.obj instanceof BluetoothClientMsg)
				doBluetoothClientMsg((BluetoothClientMsg) msg.obj);

		}

		public void doBluetoothClientMsg(BluetoothClientMsg BCM) {
			// Log.v("BluetoothClientMsg", BCM.msgType.toString() + "::" +
			// BCM.str);
			try {
				switch (BCM.msgType) {
				case OnClose:
					break;
				case OnConnect:

					BluC = BCM.client;
					BCM.client.outS.flush();

					Log.v("BluetoothClientMsg", "Send  OnConnect");
					// }
					break;
				case OnError:
					break;
				case OnMessage:

					// mc.feedInData(BCM.data, BCM.dataL);
					Log.v("OnMEssage", new String(BCM.data));
					break;
				default:
					break;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BCM.msgType = BTCMsgType.Null;
		}

	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
