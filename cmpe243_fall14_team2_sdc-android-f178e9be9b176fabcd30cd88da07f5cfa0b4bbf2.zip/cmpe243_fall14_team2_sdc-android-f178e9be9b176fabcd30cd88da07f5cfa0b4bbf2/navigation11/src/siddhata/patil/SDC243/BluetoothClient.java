package siddhata.patil.SDC243;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class BluetoothClient extends Thread {
BluetoothAdapter mBluetoothAdapter;
Handler handler;


private String DevName = null;

public BluetoothClient(Handler handler, String DevName) throws Exception {
this.handler = handler;

mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
this.DevName = DevName;
if (!Link2Dev(DevName))
throw new Exception("Device link Failed");
}

BluetoothSocket clientSocket = null;
BluetoothDevice mmDevice = null;
InputStream inS;
OutputStream outS;

public BluetoothClient(BluetoothSocket clientSocket, Handler handler)
throws IOException {

this.handler = handler;
GetSocketStream(clientSocket);

}

private boolean Link2Dev(String DevName) {

Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
for (BluetoothDevice device : devices) {
if (device.getName().contains(DevName)) {

mmDevice = device;
break;
}

}
if (mmDevice == null)
return false;

try {
// UUID string same used by server
clientSocket = mmDevice.createRfcommSocketToServiceRecord(UUID
.fromString("00001101-0000-1000-8000-00805F9B34FB"));

mBluetoothAdapter.cancelDiscovery(); // Cancel, discovery slows
// connection

clientSocket.connect();

GetSocketStream(clientSocket);

return true;

} catch (Exception e) {

/*
* Message message = handler.obtainMessage(0,"Failed");
* handler.sendMessage(message);
*/

}

return false;

}

void GetSocketStream(BluetoothSocket clientSocket) throws IOException {
inS = new DataInputStream(clientSocket.getInputStream());
outS = new DataOutputStream(clientSocket.getOutputStream());

// outS.writeBytes("sssssssssssssssssssssssss");
outS.write(5);
outS.flush();
GetMsg(BTCMsgType.OnConnect, "GetSocketStream", null, 0);
}

BluetoothClientMsg BTCMsg = new BluetoothClientMsg();
private boolean isReadLoopAlive = true;
    
void closeConnection() {
isReadLoopAlive = false;
if (clientSocket != null)

GetMsg(BTCMsgType.OnClose, "closeConnection", null, 0);

if (inS != null)
try {
inS.close();
inS = null;
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

if (outS != null)
try {
outS.close();
outS = null;
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
if (clientSocket != null)
try {
clientSocket.close();
clientSocket = null;
} catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}

ArrayList<BluetoothClientMsg> BTCMsgList=new ArrayList<BluetoothClientMsg> ();
BluetoothClientMsg getAvalibleBluetoothClientMsg()
{
for(BluetoothClientMsg msg:BTCMsgList)
if(msg.msgType== BTCMsgType.Null)
return msg;
BluetoothClientMsg msg=new BluetoothClientMsg();
BTCMsgList.add(msg);
return msg;
}
@Override
public void run() {

try {
while (isReadLoopAlive) {
// Log.v("BluetoothClient","run()");

BluetoothClientMsg msg=getAvalibleBluetoothClientMsg();
int L = inS.read(msg.data); // Read from server
msg.msgType=BTCMsgType.OnMessage;
msg.str=null;
msg.dataL=L;
Log.v("BluetoothClient","inS.read(msg.data);");
GetMsg(msg);
}
Log.v("BluetoothClient", "BluetoothClient=false");

} catch (IOException e) {
Log.v("BluetoothClient", "OnError");

GetMsg(BTCMsgType.OnError, e.getMessage(), null, 0);

}
Log.v("BluetoothClient", "closeConnection");
closeConnection();
}
private void GetMsg(BTCMsgType msgType, String str, byte[] data, int dataL) {
if (BTCMsg.msgType != BTCMsgType.Null)
BTCMsg = new BluetoothClientMsg();

BTCMsg.msgType = msgType;
BTCMsg.str = str;
BTCMsg.data = data;
BTCMsg.dataL = dataL;

BTCMsg.client = this;
handler.sendMessage(handler.obtainMessage(BTCMsg.msgType.ordinal(),
BTCMsg));
}
private void GetMsg(BluetoothClientMsg Msg) {
handler.sendMessage(handler.obtainMessage(Msg.msgType.ordinal(),
Msg));
}
}
