/*
 *     SocialLedge.com - Copyright (C) 2013
 *
 *     This file is part of free software framework for embedded processors.
 *     You can use it and/or distribute it as long as this copyright header
 *     remains unmodified.  The code is free for personal use and requires
 *     permission to use in a commercial product.
 *
 *      THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 *      OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 *      MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 *      I SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
 *      CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *     You can reach the author of this software at :
 *          p r e e t . w i k i @ g m a i l . c o m
 */

/**
 * @file
 * @brief This is the application entry point.
 * 			FreeRTOS and stdio printf is pre-configured to use uart0_min.h before main() enters.
 * 			@see L0_LowLevel/lpc_sys.h if you wish to override printf/scanf functions.
 *
 * @note  printf of %f may be turned off to save memory, this can be configured at sys_config.h
 */
#include "tasks.hpp"
#include "examples/examples.hpp"
#include "str.hpp"
#include<can.h>
#include "utilities.h"
#include "printf_lib.h"
#include "string.h"
#include "subscription_task.hpp"
#include "io.hpp"
#include "master.hpp"
#include "lpc_pwm.hpp"




int main(void)
{

    Uart3& u3 = Uart3::getInstance();
    u3.init(115200);

    // Set PWM to 50%
    // This is a HACK, motor controller should've figured it out
    PWM hackedSignalForIrMotorMovementDecoding(PWM::pwm1, 38000);
    hackedSignalForIrMotorMovementDecoding.set(50);

    InitializeCan();

    SetCANFilter(MASTER_CAN29_EXGRP1START,MASTER_CAN29_EXGRP1END);


    scheduler_add_task(new terminalTask(PRIORITY_HIGH));

    addSubscriptionTasks(PRIORITY_MEDIUM);



    scheduler_add_task(new canMsgRecieveTask  (0,PRIORITY_MEDIUM,"RecieveTask",6*512));
    scheduler_add_task(new canDataSendTask  (0,PRIORITY_MEDIUM,"SendTask",6*512));

    scheduler_start();

    while(1)
    {

    }

    return -1;
}
