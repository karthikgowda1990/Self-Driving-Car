/*
 * Errors.h
 *  This file contains all error codes which all board would log in the log file
 *  and send back to the master.
 *  Created on: Oct 19, 2014
 *      Author: h.siyamwala
 */

#ifndef ERRORS_H_
#define ERRORS_H_

/*
 *
 * Error codes are specified are specified in following order
 * byte[2-3] - BoardId
 * byte[0-1] - Error Message pertaining to that board
 *
 */

typedef enum MasterErrCodes{
    MASTER_SUCCESS = 0x5000,
    MASTER_ROUTE_LOST_FAILURE=0x5001,
    MASTER_SENSOR_DATA_CORRUPTED=0x5002,
    MASTER_COMPASS_CALIBRATION_FAILURE=05003,

} MasterErrCodes;

/// All these Error codes are for individual board
typedef enum GPSErrCodes{
   GPS_SUCCESS = 0x5100,
   GPS_CORDINATES_RETREIVAL_FAILURE=0x5101,
   GPS_CAN_MESSAGE_FAILURE,

} GPSErrCodes;

typedef enum MotorErrCodes{
    MOTOR_SUCCESSS=0x5200,

} MotorErrCodes;

typedef enum SensorErrCodes{
    SENSOR_SUCCESS = 0x5300,
} SensorErrCodes;

typedef enum DisplayErrCodes{
    DISPLAY_SUCCESS = 0x5400,
} DisplayErrCodes;

typedef enum AndroidErrCodes{
    ANDROID_SUCCESS = 0x5500,
} AndroidErrCodes;
#endif /* ERRORS_H_ */
