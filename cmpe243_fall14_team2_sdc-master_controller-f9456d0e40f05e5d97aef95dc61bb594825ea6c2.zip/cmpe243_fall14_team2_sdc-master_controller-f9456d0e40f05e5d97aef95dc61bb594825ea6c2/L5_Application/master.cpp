/*
 * master.cpp
 *
 *  Created on: Oct 20, 2014
 *      Author: Roady
 */

#include "master.hpp"

canDataSendTask::canDataSendTask(uint16_t periodMs, uint8_t priority,const char* taskName,uint32_t stackSize) :
                scheduler_task(taskName,stackSize, priority),
                mTaskPeriodMs(periodMs),mCanDatasize(0)
            {
                setRunDuration(periodMs);
            }


bool canDataSendTask::run(void *p)
{
    if(SW.getSwitch(3)){
    puts("Publish Dummy Data by calling PublishSubscribedMessageData\n");

     memset(&mCanData, 0, sizeof(mCanData));
     mCanData[0]=1;
     mCanDatasize=1;

     canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_master_subsc_setMotorData),mCanData,mCanDatasize);
     }
    else if(SW.getSwitch(1)){

    puts("Sending CAN subsription message to motor\n");


     memset(&mCanMsg, 0, sizeof(mCanMsg));

     memset(&mCanData, 0, sizeof(mCanData));
     mCanData[0]=50;
     // 0the member of data array has subscription message frequency
     mCanDatasize=1;

     mCanMsg=CreateCANMessage(0,0x0525040B,1,1,(const char*)mCanData);
     CAN_tx(can1, &mCanMsg, 0);
     }
    else if(SW.getSwitch(2))
    {

        puts("Sending CAN subsription message to Compass\n");


         memset(&mCanMsg, 0, sizeof(mCanMsg));

         memset(&mCanData, 0, sizeof(mCanData));
         mCanData[0]=50;
         // 0the member of data array has subscription message frequency
         mCanDatasize=1;
         //mid_geo_subsp_data
         mCanMsg=CreateCANMessage(0,0x0515041C,1,1,(const char*)mCanData);
         CAN_tx(can1, &mCanMsg, 0);
    }

     return true;
    }




static void  subscription_add(can_msg_t* msg)
{
    if(msg==NULL)return;

    uint8_t srcId = ((*msg).msg_id>>CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (*msg).msg_id & 0xfffU | 0x00000100;//changing subscription message to subscribed message

#ifdef DEBUG_SUBSCRIPTION_TASK
    printf("message id is: %x,src id is: %x\n ",(*msg).msg_id, srcId);
#endif

    msgRate_t msgRate=convertHzTomsdRateEnum((*msg).data.bytes[0]);
    canSubscribedMsgTask::addSubscribedMsg(msgRate,srcId,msgId, msg);

}


canMsgRecieveTask::canMsgRecieveTask(uint16_t periodMs,uint8_t priority,const char* taskName,const uint32_t stackSize) :
            scheduler_task(taskName,stackSize, priority),
            mTaskPeriodMs(periodMs)
    {
            setRunDuration(periodMs);
    }


bool canMsgRecieveTask::run(void *p)
{
    if(CAN_rx(can1,&mmsg,portMAX_DELAY))
    {

        can_msg_t* msg= new can_msg_t;

        if(msg==NULL)
            return false;

        switch(mmsg.msg_id&(0xfffU))
        {
            case 0x400 ... 0x4FF:
#ifdef DEBUG_SUBSCRIPTION_TASK
            puts("MASTER: CAN subscription message got");
            printf(" with message id:%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
            memset(msg, 0, sizeof(msg));
            *msg=mmsg;
            subscription_add(msg);

            break;

            case 0x500 ... 0x5FF:
#ifdef DEBUG_SUBSCRIPTION_TASK
            puts("MASTER: CAN subscribed message got");
            printf(" with message id:%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
            break;

            default:
                delete msg;
#ifdef DEBUG_SUBSCRIPTION_TASK
                printf("MASTER: Unexpected message id got(master):%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
                break;
        };

    }

    return true;
}
