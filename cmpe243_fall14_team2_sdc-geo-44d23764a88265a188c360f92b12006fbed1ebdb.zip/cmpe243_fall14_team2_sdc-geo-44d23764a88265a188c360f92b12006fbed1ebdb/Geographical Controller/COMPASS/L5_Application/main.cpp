/*
 *     SocialLedge.com - Copyright (C) 2013
 *
 *     This file is part of free software framework for embedded processors.
 *     You can use it and/or distribute it as long as this copyright header
 *     remains unmodified.  The code is free for personal use and requires
 *     permission to use in a commercial product.
 *
 *      THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 *      OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 *      MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 *      I SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
 *      CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *     You can reach the author of this software at :
 *          p r e e t . w i k i @ g m a i l . c o m
 */
/*Adding new Comment*/

/**
 * @file
 * @brief This is the application entry point.
 */

#include <stdio.h>
#include<iostream>
#include<ssp1.h>
#include<can.h>
#include "utilities.h"
#include "printf_lib.h"
#include "string.h"
#include "tasks.hpp"
#include "str.hpp"
#include "examples/examples.hpp"
#include "io.hpp"
#include "subscription_task.hpp"
#include "geo.hpp"


int main(void)
{
	// Compass Testing
	//	COMPASS oCompass = COMPASS::getInstance();
	//	while(true)
	//	{
	//		oCompass.initializeCompass();
	//		printf("Compass Reading: %d\n", oCompass.GetCompassDegree());
	//		delay_ms(1000);
	//	}

	InitializeCan();
    LD.setNumber((char)0);
    //setup CAN message id for switch on and switch off turned off
    LOG_INFO("\nReset\n");

    SetCANFilter(GPS_CAN29_EXGRP1START, GPS_CAN29_EXGRP1END);

    scheduler_add_task(new terminalTask(PRIORITY_HIGH));

    addSubscriptionTasks(PRIORITY_MEDIUM);


    scheduler_add_task(new canMsgRecieveTask(10, PRIORITY_MEDIUM, "CanMsgRecieveTask", 3 * 512));
    scheduler_add_task(new canDataSendTask  (10, PRIORITY_MEDIUM, "canMsgSendTask", 10 * 512));

    scheduler_start();

    return 0;
}
