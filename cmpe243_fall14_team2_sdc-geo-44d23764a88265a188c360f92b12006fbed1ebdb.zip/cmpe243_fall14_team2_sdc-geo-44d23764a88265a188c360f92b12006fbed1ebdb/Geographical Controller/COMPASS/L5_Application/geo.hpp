/*
 * geo.hpp
 *  Created on: 11/1/2014
 *      Author: Harsh
 */

#ifndef GEO_HPP_
#define GEO_HPP_
#include "printf_lib.h"
#include <stdio.h>
#include <iostream>
#include <stdint.h>
#include <string.h>
#include <vector>

#include "subscription_task.hpp"
#include "scheduler_task.hpp"
#include "utilities.h"
#include "soft_timer.hpp"
#include "command_handler.hpp"
#include "wireless.h"
#include "char_dev.hpp"
#include "FreeRTOS.h"
#include "semphr.h"
#include "subscription_task.hpp"
#include "can.h"
#include "file_logger.h"
#include "io.hpp"
//#include "vector.hpp"					// smaller footprint than <vector>, might have some issue
#include "singleton_template.hpp"
#include "compass.hpp"
#include "gps.hpp"

#define CMD_DESTINATION_REACHED	4000	// send command if destination is reached
#define ALLOWED_DIST_TOLERANCE 7		// moved current destination coordinate to next if difference if less than 5 meter

//#define DEBUG_GEO 1


class GEO:public SingletonTemplate<GEO>
{
	private:
		GEO() { }
		std::vector<double> vtAndroidWaypointLogitude;
		std::vector<double> vtAndroidWaypointLatitude;
		int iCurrentDestination = 0;
		int iFinalDestination = 0;
		double dDistanceToCurrentDestination = 0.0;		// distance between current position and current destination
		double dDistanceToFinalDestination = 0.0;		// total distance between source and destination
		bool isDestinationReached = false;
		friend class SingletonTemplate<GEO>;
	public:
		// note: why passing by value wasn't working ?? might require copy constructor
		std::vector<double>& getAndroidWaypointLongitudeInfo() { return vtAndroidWaypointLogitude; }
	 	std::vector<double>& getAndroidWaypointLatitudeInfo() { return vtAndroidWaypointLatitude; }

		int getReceivedLatitudeCount() { return (vtAndroidWaypointLatitude.size()); }
		int getReceivedLongitudeCount() { return (vtAndroidWaypointLogitude.size()) ; }
		int getReceivedCoordinateCount() { return (vtAndroidWaypointLogitude.size() >= vtAndroidWaypointLatitude.size()) ? vtAndroidWaypointLogitude.size() : vtAndroidWaypointLatitude.size(); }
		void addAndroidLongitudeEntry(double d_Longitude) { vtAndroidWaypointLogitude.push_back(d_Longitude); };
		void addAndroidLatitudeEntry(double d_Latitude) { vtAndroidWaypointLatitude.push_back(d_Latitude); };

		void setCurrentDestination(int currentDestination) { iCurrentDestination = currentDestination; }
		int getCurrentDestination() { return iCurrentDestination; }

		void setFinalDestination()
		{
			iFinalDestination = (vtAndroidWaypointLogitude.size() == vtAndroidWaypointLatitude.size()) ? getReceivedCoordinateCount() - 1 : 0;
			printf("Final Destination Location  %d\n",iFinalDestination);
			dDistanceToFinalDestination = (iFinalDestination > 0) ? ComputeDistanceM(vtAndroidWaypointLatitude[0], vtAndroidWaypointLogitude[0], vtAndroidWaypointLatitude[iFinalDestination], vtAndroidWaypointLogitude[iFinalDestination]) : 0.00;
		}
		void setDistanceToFinalDestination(double distanceToFinalDestination) { dDistanceToFinalDestination = distanceToFinalDestination; }
		double getDistanceToFinalDestination() { return dDistanceToFinalDestination; }

		int getFinalDestination() { return iFinalDestination; }
		bool getIsDestinationReached() { return isDestinationReached; }

		double getCurrentDestinationLongitude() { return vtAndroidWaypointLogitude[iCurrentDestination]; }
		double getCurrentDestinationLatitude() { return vtAndroidWaypointLatitude[iCurrentDestination]; }

		double ComputeDistanceM(double lat1, double long1, double lat2, double long2);
		void updateCurrentDestination(double dCurrentLongitude, double dCurrentLatitude);	// also it will set destination reached flag
};

// CAN data send task - it will send compass heading, bearing, destination reached command to master
class canDataSendTask : public scheduler_task
{
	public:
	   canDataSendTask(uint16_t periodMs, uint8_t priority,const char* taskName,uint32_t stackSize);
	   bool run(void *p);
	private:
		const uint16_t mTaskPeriodMs;
		uint8_t mCanData[8];
		uint8_t mCanDatasize;
		can_msg_t mCanMsg;
		void logCANMessageTransmit();
};

static void  subscription_add(can_msg_t* msg);

// CAN data receive task - receive multiple waypoints from Android App to navigate from source to destination
class canMsgRecieveTask : public scheduler_task
{
   public:
	   canMsgRecieveTask(uint16_t periodMs, uint8_t priority,const char* taskName,uint32_t stackSize);
	   bool run(void *p);
   private:
	   const uint16_t mTaskPeriodMs;
	   can_msg_t mmsg;
	   void logCANMessageRecieve();
};

#endif  /* GEO_HPP_ */
