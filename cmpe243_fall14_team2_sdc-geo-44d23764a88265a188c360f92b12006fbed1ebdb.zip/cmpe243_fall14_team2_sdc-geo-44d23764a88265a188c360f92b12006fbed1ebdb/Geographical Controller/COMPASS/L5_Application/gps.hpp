/*
 * gps.hpp
 * Created on: 10/21/2014
 * Author: Harsh, Yash
 */
/*
 * Description: UART drivers for GPS module :Venus GPS
 * GPS Module Properties:
 * Firmware version: ???
 * Interface UART	*/
#ifndef GPS_HPP_
#define GPS_HPP_

#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <stdlib.h>     /* strtod */
#include <math.h>		// M_PI
#include "uart_dev.hpp"
#include "scheduler_task.hpp"
#include "singleton_template.hpp"

//#define DEBUG_GPS 1

#define GPS_BAUD_RATE 			115200 				// default for Venus GPS (supports 10/20Hz)
#define GPS_BAUD_RATE_OLD 		4800 				// older GPS used temporarily
#define GPS_MAX_NMEA_SENTENCE 	200

class GPS : public SingletonTemplate<GPS>
{
	private:
		// Stored in degree-decimal_minute (37 33.7000, <DEGREE MINUTE.MINUTE_FRACTION>) format
		std::string s_NMEASentence;
		std::string s_UTCTime;			// To Do: Get time stamp from GPS and convert to PDT
		double d_latitude;
		double d_longitude;
		char c_isvalid;
		// For internal tracking
		unsigned int i_numReadings;
		// time stamp
	public:
		GPS();
		double getLatitude();
		double getLongitude();

		double converttodecimal(double degree);
		double ConvertDMSToDD(double dDegreeMinute);

		std::string gpsReadNMEASentence_OLD();
		std::string gpsReadNMEASentence();
		void initializeGPS();
		void initializeGPS_OLD();
};


#endif /* GPS_HPP_ */


/*
Sample Data

GPS Test Program
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010211.694,1*7F
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010212.694,1*7C
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010213.695,1*7C
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010214.696,1*78
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010215.696,1*79
GPRPT,37.337012,N,121.882774,W,00000,0000.0,228.92,021114,010216.693,1*7F
*/
