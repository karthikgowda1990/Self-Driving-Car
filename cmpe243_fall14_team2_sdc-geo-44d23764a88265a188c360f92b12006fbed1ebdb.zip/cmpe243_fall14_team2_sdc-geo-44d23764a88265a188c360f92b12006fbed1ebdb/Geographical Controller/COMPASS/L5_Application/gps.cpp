/*
 * gps.cpp
 * Created on: 10/21/2014
 * Author: Harsh, Yash
 */
/*Adding new Comment*/

#include<iostream>
#include "gps.hpp"
#include "uart2.hpp"
#include "utilities.h"
#include "printf_lib.h"

char sentence_1[GPS_MAX_NMEA_SENTENCE];
char sentence_2[GPS_MAX_NMEA_SENTENCE];

std::string getField(int);

/*DO NOT ADD PRINTF ANYWHERE*/
 /*DO NOT ADD PRINTF ANYWHERE*/
 /*DO NOT ADD PRINTF ANYWHERE*/

//
double converttodecimal(double degree)
{
    int temp=degree;

    int degrees=temp/100;
    int minutes=temp%100;
    int seconds=(degree-temp)*10000;

    return (degrees+(minutes/60.0)+(seconds/3600.0));
}



GPS::GPS()
{
    this->s_NMEASentence = "";
    this->d_latitude = 0.00;
    this->d_longitude = 0.00;
}

void GPS::initializeGPS()
{
    double latindegrees;
    double longindegrees;

#ifdef DEBUG_GPS
	printf("INisde GPS \n");
#endif
    this->s_NMEASentence = gpsReadNMEASentence();
    std::string s_Latitude = getField(2);
    std::string s_Longitude = getField(4);
    //puts("Before Conversion Lat and Long::");
    //puts(s_Latitude.c_str());
    //puts(s_Longitude.c_str());
    latindegrees = (s_Latitude != "") ? strtod(s_Latitude.c_str(), NULL) : 0.00;
    longindegrees = (s_Longitude != "") ? strtod(s_Longitude.c_str(), NULL) : 0.00;

    this->d_latitude=this->ConvertDMSToDD(latindegrees);
    this->d_longitude=this->ConvertDMSToDD(longindegrees);


    //printf("GPS.initializeGPS() - %s\n", this->s_NMEASentence.c_str());
    //printf("Latitude: %s, Longitude: %s\n", s_Latitude.c_str(), s_Longitude.c_str());
    //printf("Latitude: %f, Longitude: %f\n", this->d_latitude, this->d_longitude);
}

std::string GPS::gpsReadNMEASentence()
{
    /*DO NOT ADD PRINTF ANYWHERE*/
    /*DO NOT ADD PRINTF ANYWHERE*/
    /*DO NOT ADD PRINTF ANYWHERE*/

    Uart2& u2 = Uart2::getInstance();
    // 11/1/2014 - updated temporarily to 4800 for older GPS, For new GPS later changed it to 9600 or 38400 (10Hz frequency configuration)
    u2.init(GPS_BAUD_RATE, 100);

    int i = 0;
    std::string sen;
    char* ch;
    char buff;

	while(true)
	{
		while(true)
		{
			buff = '\0';
			ch = &buff;

			while(u2.getChar(ch, portMAX_DELAY) == 0) continue;

			if (*ch != '$' && i < GPS_MAX_NMEA_SENTENCE)
			{
				if(*ch == 0x0d) continue;		// 0x0d - line feed
				sentence_1[i] = *ch;
//				printf("%d, %c\n",i, *ch);
				i++;
			}
			else
			{
			    sentence_1[i] = '\0';
				i = 0;
				break;
			}
		}

		std::string s_TmpSentances = sentence_1;
		std::size_t found = s_TmpSentances.find("GPRMC");	// ignore this line
		if(found)
			break;
	}
	puts("gps data: ");
	puts(sentence_1);
    return sentence_1;

	//return "GPGGA,120403.000,5555.555,N,55555.5656,E,0,00,0.0,0.0,M,0.0,M,,0000*69";
}

void GPS::initializeGPS_OLD()
{
    this->s_NMEASentence = gpsReadNMEASentence();
    std::string s_Latitude = getField(1);
    std::string s_Longitude = getField(3);

    this->d_latitude = (s_Latitude != "") ? strtod(s_Latitude.c_str(), NULL) : 0.00;
    this->d_longitude = (s_Longitude != "") ? strtod(s_Longitude.c_str(), NULL) : 0.00;

    //printf("GPS.initializeGPS() - %s\n", this->s_NMEASentence.c_str());
    //printf("Latitude: %s, Longitude: %s\n", s_Latitude.c_str(), s_Longitude.c_str());
    //printf("Latitude: %f, Longitude: %f\n", this->d_latitude, this->d_longitude);
}

std::string GPS::gpsReadNMEASentence_OLD()
{
    Uart2& u2 = Uart2::getInstance();

    // 11/1/2014 - updated temporarily to 4800 for older GPS, For new GPS later changed it to 9600 or 38400 (10Hz frequency configuration)
    u2.init(GPS_BAUD_RATE);

    int i = 0;
    char* ch;
    while (true)
    {
        char buff = '\0';
        ch = &buff;

        while (u2.getChar(ch, portMAX_DELAY) == 0)
            continue;

        if (*ch != '$' && i < GPS_MAX_NMEA_SENTENCE)
        {
            if (*ch == 0x0d)
                continue; // 0x0d - line feed
            sentence_1[i] = *ch;
            i++;
        }
        else
        {
            sentence_1[i] = '\0';
            i = 0;
            break;
        }
    }

    return sentence_1;
}

double GPS::getLatitude()
{
    return this->d_latitude;
}

double GPS::getLongitude()
{
    return (-1) * (this->d_longitude); // To Do: remove (-1)
}

// Convert from DMS (degrees, minutes, secondes) to DD (decimal degrees), New GPS format: ddmm.mmmm
double GPS :: ConvertDMSToDD(double dDegreeMinute)
{
    int degree = dDegreeMinute / 100;
    double decDegree = fmod(dDegreeMinute, 100) / 60.0;
    return degree + decDegree;
}

double GPS :: converttodecimal(double degree)
{
    int temp=degree;

    int degrees = temp/100;
    int minutes = temp%100;
    int seconds = (degree-temp)*100;

    //std::cout << "Degree: " << degrees << ", Minutes: " << minutes << ", Seconds: " << seconds << "\n";

    return (degrees+(minutes/60.0)+(seconds/3600.0));
}


std::string getField(int index)
{
    char field[20];
    int sentencePos = 0;
    int fieldPos = 0;
    int commaCount = 0;
    while (sentencePos < GPS_MAX_NMEA_SENTENCE)
    {
        //printf("%c\n", sentence[sentencePos]);
        if (sentence_1[sentencePos] == ',')
        {
            commaCount++;
            sentencePos++;
        }
        if (commaCount == index)
        {
            field[fieldPos] = sentence_1[sentencePos];
            fieldPos++;
            //printf("commaCount == index -> %c\n", sField[fieldPos]);
        }
        sentencePos++;
        if (commaCount > index)
            break; // avoid looping
    }
    field[fieldPos] = '\0';

    std::string sField(field);
    return sField;
}


/*
 * Documentation:
 * PRIMARY GOAL:
 * 1)Run GPS in default mode:
 * 	a)Format: WGS-84
 * 	b)Update rate: 1Hz
 * 2)Transmit on CAN running at 10Hz although the OG rate is 1Hz.
 * 	SECONDARY GOAL:
 * 		1) upgrade to 10 Hz, change format: change format to GGA and upgrade baud rate if necessary
 * 	TERTIARY GOAL:
 * 		1) Look into GPS pinning mode and
 * 	Create 10Hz task
 * */
