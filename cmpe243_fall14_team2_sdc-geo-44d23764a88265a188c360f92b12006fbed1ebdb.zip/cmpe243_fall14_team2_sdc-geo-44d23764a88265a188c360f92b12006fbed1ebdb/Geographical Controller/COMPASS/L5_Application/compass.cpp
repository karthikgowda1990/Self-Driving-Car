/*
 *  compass.cpp
 *  Created on: Oct 13, 2014
 *  Author: Harsh, Ajinkya, Anand
 */

/*Adding new Comment*/

#include "boardIds.hpp"
#include "compass.hpp"
#include "math.h"
#include "geo.hpp"

const float pi = 3.141592653589793;

static volatile bool startBoard = true;
static volatile bool destinationReached = false;

//static double dLastReading = 0.00;
static float lastValidReading = 0.00;

float meanCompassData(float *compassReadingSample, int SAMPLE_COUNT);

COMPASS::COMPASS()
{
    iCompassDegree = 0;
    iBearing = 0;
}

void COMPASS::initializeCompass()
{
    const int SAMPLE_COUNT = 5;
    bool isSuccess = 1;
    float d_HeadingDegree = 0.00;
    float mean;
    float compassReadingSample[SAMPLE_COUNT] = { 0 };
    char receiveddata[2] = { 0, 0 };

#ifdef DEBUG_SUBSCRIPTION_TASK
    puts("Compass:Inside GetCompassData\n");
#endif

    ////////////// 	-- Copy test code from main 	-- 		/////////////////////////////////
    I2C2& i2c2 = I2C2::getInstance(); // Get I2C driver instance
    i2c2.init(100); // 100 KHz

    const char deviceAddress = 0x42; // Your device address
    const char firstReg = 0x00; // Write to 1st register of your device
    const char cmdGetData = 'A'; // Write 'A' to reg 0x42

    // Take multiple readings and get its Median
    for (int i = 0; i < SAMPLE_COUNT; i++)
    {
        //printf("Iteration %d: Data Write starts\n", i);
        // Send a "Get Data" command to the compass
        if (!(i2c2.writeReg(deviceAddress, firstReg, cmdGetData))) // my_dev_addr, my_dev_reg, 'A'
        {
            printf("Iteration %d: HMC6352 Communication Error!\n\r", i);
            isSuccess = 0;
        }
        //printf("Iteration %d: Data Written\n", i);
        delay_ms(7);

        //printf("Iteration %d: Data Read starts\n", i);

        // read two bytes of data
        if (i2c2.readRegisters(deviceAddress, firstReg, receiveddata, 2))
        {
            // Compute and print out a heading, convert to floating point and 0.1 degree accuracy
            d_HeadingDegree = ((receiveddata[0] << 8) + receiveddata[1]) / 10.0;
            //printf("Iteration %d: Heading - %3.1f degree\n", i, d_HeadingDegree);

            //DO we need this?
            delay_ms(8); // Wait to avoid spamming too much; for SAMPLE_COUNT = 7, approx delay is now 161ms
        }

        LOG_INFO("Last Reading: %lf,Heading: %lf", lastValidReading, d_HeadingDegree);

        // 12/13/2014 - Avoid negative compass reading (To Do: Proper compass calibration)
        //d_HeadingDegree = (d_HeadingDegree > 0) ? d_HeadingDegree : dLastReading;
        //dLastReading = d_HeadingDegree;

        /*Compass Correction Logic - */
//        if (d_HeadingDegree <= 0)
//        {
//            printf("Adding Correction Logic...\n");
//            d_HeadingDegree = fmod(
//                    (lastValidReading + (12 - abs(d_HeadingDegree))), 360);
//        }
//        else
//        {
//            lastValidReading = d_HeadingDegree;
//        }
        //printf("Iteration %d: Data Read Successful\n", i);
        d_HeadingDegree += 14.0;
        d_HeadingDegree = fmod(d_HeadingDegree ,360.0);

        if (d_HeadingDegree >= 0)
        {
            this->iCompassDegree = (uint16_t) (d_HeadingDegree * 10);
            //printf("Compass.cpp, %d\n", this->iCompassDegree);
        }
    }
    ///////////////////////////////////////////////////////////////////////////

    // Sort the readings and take the median
    //mean = meanCompassData(compassReadingSample, SAMPLE_COUNT);
    //printf("Mean: %f \n", mean);
    //this->iCompassDegree = (uint16_t) (mean * 10);
}

float toRad(float degreeRading)
{
    return degreeRading * pi / 180;
}

float toDegree(float radReading)
{
    return radReading * 180 / pi;
}

float meanCompassData(float *compassReadingSample, int SAMPLE_COUNT)
{
    float sum = 0;
    int i;
    for (i = 0; i < SAMPLE_COUNT; i++)
    {
        if (compassReadingSample[i] >= 0)
        {
            sum = compassReadingSample[i] + sum;
        }
    }

    return sum / SAMPLE_COUNT;
}

// Given the current location and destination, get the direction in degree (N-E) and return it to master
void COMPASS::updateCompassBearing(double dCurLatitude, double dCurLongitude, double dDestLatitude, double dDestLongitude)
{
    //TODO: for the time being, hardcode current and destination coordinates. In future they will come from the waypointsData array
    float currentLat, currentLong, destinationLat, destinationLong;

    //Lucas graduate school
    //printf("Calling GPS init \n");
    //oGPS.initializeGPS();
    currentLat = dCurLatitude; //37.337073;
    currentLong = dCurLongitude; //-121.87894719999997;

    //151-199 South 10th Street, San Jose, CA 95112, USA    --> 37.3374415, -121.87862740000003
    destinationLat = dDestLatitude; // other co-ordinate for test	,
    destinationLong = dDestLongitude; // other co-ordinate for test

    //printf("\nVector Data\n");
    //printf("Length: %d, %d\n", oGeo.getAndroidWaypointLatitudeInfo().size(), oGeo.getAndroidWaypointLongitudeInfo().size());


//    if (!oGeo.getAndroidWaypointLatitudeInfo().isEmpty() && !oGeo.getAndroidWaypointLongitudeInfo().isEmpty())
//    {
//        destinationLat = oGeo.getAndroidWaypointLatitudeInfo().front();
//        destinationLong = oGeo.getAndroidWaypointLongitudeInfo().front();
//    }

//    printf("Current coordinates DD - CurrentLat: %f, CurrentLong: %f \n", currentLat, currentLong);
//    printf("Destination coordinates DD - DestLat: %f, DestLong: %f \n", destinationLat, destinationLong);

    float dLat = toRad(destinationLat - currentLat);
    float dLon = toRad(destinationLong - currentLong);

    float lat1 = toRad(currentLat);
    float lat2 = toRad(destinationLat);
    //printf("Current coordinates (rad) - Lat: %f \n Long: %f \n", lat1, lat2);

    float y = sin(dLon) * cos(lat2);
    float x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
    float brng = toDegree(atan2(y, x));

    // fix negative degrees
    if (brng < 0)
    {
        brng = 360 - abs(brng);
    }

    //printf("Raw bearing - %f \n", brng);
    //printf("Corrected bearing - %f \n", brng - currentHeading);

    //Subtracting magnetic declination of 14 degree east
    this->iBearing = (uint16_t) ((brng) * 10);

    /*NOW subtract heading data from the bearing data.
     * if (bearing - heading) > 0 :: turn east(clockwise) by that much amount
     * if (bearing - heading) < 0 :: turn west(anti-clockwise) by that much amount
     * Master needs to do this*/
}

//bool GetCompassData(uint8_t * const canDataArray, uint8_t& dataSize)
//{
//    // TODO: How do we handle the negative readings?
//    // specify the sample size for compass readings; we then sort and take its median
//    const int SAMPLE_COUNT = 5;
//    bool isSuccess = 1;
//    float d_HeadingDegree = 0.00;
//    float mean;
//    float compassReadingSample[SAMPLE_COUNT] = { 0 };
//    char receiveddata[2] = { 0, 0 };
//
//#ifdef DEBUG_SUBSCRIPTION_TASK
//    puts("Compass:Inside GetCompassData\n");
//#endif
//
//    ////////////// 	-- Copy test code from main 	-- 		/////////////////////////////////
//    I2C2& i2c2 = I2C2::getInstance(); // Get I2C driver instance
//    i2c2.init(100); // 100 KHz
//
//    const char deviceAddress = 0x42; // Your device address
//    const char firstReg = 0x00; // Write to 1st register of your device
//    const char cmdGetData = 'A'; // Write 'A' to reg 0x42
//
//    // Take multiple readings and get its Median
//    for (int i = 0; i < SAMPLE_COUNT; i++)
//    {
//        //printf("Iteration %d: Data Write starts\n", i);
//        // Send a "Get Data" command to the compass
//        if (!(i2c2.writeReg(deviceAddress, firstReg, cmdGetData))) // my_dev_addr, my_dev_reg, 'A'
//        {
//            printf("Iteration %d: HMC6352 Communication Error!\n\r", i);
//            isSuccess = 0;
//        }
//        //printf("Iteration %d: Data Written\n", i);
//        delay_ms(7);
//
//        //printf("Iteration %d: Data Read starts\n", i);
//
//        // read two bytes of data
//        if (i2c2.readRegisters(deviceAddress, firstReg, receiveddata, 2))
//        {
//            // Compute and print out a heading, convert to floating point and 0.1 degree accuracy
//            d_HeadingDegree = ((receiveddata[0] << 8) + receiveddata[1]) / 10.0;
//            //printf("Iteration %d: Heading - %3.1f degree\n", i, d_HeadingDegree);
//
//            //DO we need this?
//            delay_ms(15); // Wait to avoid spamming too much; for SAMPLE_COUNT = 7, approx delay is now 161ms
//        }
//        if (d_HeadingDegree > 0)
//        {
//            //printf("Iteration %d: Data Read Successful\n", i);
//            compassReadingSample[i] = d_HeadingDegree;
//        }
//        else
//            i--;
//    }
//    ///////////////////////////////////////////////////////////////////////////
//
//    // Sort the readings and take the median
//    mean = meanCompassData(compassReadingSample, SAMPLE_COUNT);
//    printf("Mean: %f \n", mean);
//
//    //TODO: We will receive a struct from geo.cpp which contains android data
//    //Use it to calculate the bearing
//    float bearing = GetBearingData(mean);
//    printf("Bearing: %f", bearing);
//
//    uint16_t iHeadingDegree = (uint16_t) (mean * 10);
//    uint16_t iBearing = (uint16_t) (bearing * 10);
//
//    uint16_t* temp = (uint16_t*) canDataArray;
//
//    if (!destinationReached)
//    {
//        // canDataArray[0] = iHeadingDegree; // NOTE: we have to discuss data format
//        temp[0] = iHeadingDegree;
//        temp[1] = iBearing;
//    }
//    else
//    {
//        /* send 4000 to signal destination reached*/
//        temp[0] = iHeadingDegree;
//        temp[1] = 4000;
//    }
//
//    dataSize = 4;
//
//    printf("Compass:%d \n Bearing:%d", iHeadingDegree, iBearing);
//    // LOG_INFO("%d\n", iHeadingDegree); // end of reading line, last value is a median value
//    return isSuccess;
//}

/*Given the current location and destination, get the direction in degree (N-E) and return it to master*/
//float GetBearingData(float currentHeading)
//{
//	 GEO& oGeo = GEO::getInstance();
//	 GPS& oGPS = GPS::getInstance();
//
//    //TODO: for the time being, hardcode current and destination
//    //coordinates. In future they will come from the waypointsData array
//
//    float currentLat, currentLong, destinationLat, destinationLong;
//
//    //Lucas graduate school
//
//    //printf("Calling GPS init \n");
//    oGPS.initializeGPS();
//    currentLat = oGPS.getLatitude(); //37.337073;
//    currentLong = oGPS.getLongitude(); //-121.87894719999997;
//
//    //151-199 South 10th Street, San Jose, CA 95112, USA    --> 37.3374415, -121.87862740000003
//    destinationLat = 37.334840; // other co-ordinate for test	,
//    destinationLong = -121.880923; // other co-ordinate for test
//
//    //printf("\nVector Data\n");
//    //printf("Length: %d, %d\n", oGeo.getAndroidWaypointLatitudeInfo().size(), oGeo.getAndroidWaypointLongitudeInfo().size());
//
//    if(oGeo.getAndroidWaypointLatitudeInfo().size() > 0)
//    	printf("Element: %f, %f\n,", oGeo.getAndroidWaypointLatitudeInfo()[0]);
//
//    if (!oGeo.getAndroidWaypointLatitudeInfo().isEmpty() && !oGeo.getAndroidWaypointLongitudeInfo().isEmpty())
//    {
//        destinationLat = oGeo.getAndroidWaypointLatitudeInfo().front();
//        destinationLong = oGeo.getAndroidWaypointLongitudeInfo().front();
//    }
//
//    printf("Current coordinates DD - CurrentLat: %f, CurrentLong: %f \n", currentLat, currentLong);
//    printf("Destination coordinates DD - DestLat: %f, DestLong: %f \n", destinationLat, destinationLong);
//
//
//    float dLat = toRad(destinationLat - currentLat);
//    float dLon = toRad(destinationLong - currentLong);
//
//    //printf("Current Heading - CurrentHeading: %f \n", currentHeading);
//
//    float lat1 = toRad(currentLat);
//    float lat2 = toRad(destinationLat);
//
//    //printf("Current coordinates (rad) - Lat: %f \n Long: %f \n", lat1, lat2);
//
//    float y = sin(dLon) * cos(lat2);
//    float x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
//    float brng = toDegree(atan2(y, x));
//
//    // fix negative degrees
//    if (brng < 0)
//    {
//        brng = 360 - abs(brng);
//    }
//
//    //printf("Raw bearing - %f \n", brng);
//    //printf("Corrected bearing - %f \n", brng - currentHeading);
//
//    //Subtracting magnetic declination of 14 degree east
//    return brng - 14;
//
//    /*NOW subtract heading data from the bearing data.
//     * if (bearing - heading) > 0 :: turn east(clockwise) by that much amount
//     * if (bearing - heading) < 0 :: turn west(anti-clockwise) by that much amount
//     * Master needs to do this*/
//}
