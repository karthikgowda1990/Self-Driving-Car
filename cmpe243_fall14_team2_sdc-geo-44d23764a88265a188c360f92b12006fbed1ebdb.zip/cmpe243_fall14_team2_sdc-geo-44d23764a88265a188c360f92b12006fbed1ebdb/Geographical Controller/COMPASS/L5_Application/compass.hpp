/*
 * compass.hpp
 *
 *  Created on: Oct 13, 2014
 *      Author: Harsh, Ajinkya, Anand
 */

#ifndef COMPASS_HPP_
#define COMPASS_HPP_

#include "printf_lib.h"
#include <stdio.h>
#include <iostream>
#include <stdint.h>
#include <string.h>

#include "subscription_task.hpp"
#include "scheduler_task.hpp"
#include "utilities.h"
#include "soft_timer.hpp"
#include "command_handler.hpp"
#include "wireless.h"
#include "char_dev.hpp"
#include "FreeRTOS.h"
#include "semphr.h"
#include "subscription_task.hpp"
#include "can.h"
#include "io.hpp"
#include "geo.hpp"

//#include "geo.hpp"
#include "gps.hpp"              // to do: remove later, added temporarily for testing

bool GetCompassData(uint8_t *const canDataArray,uint8_t& dataSize);
bool GetGPSData(uint8_t *const canDataArray, uint8_t& dataSize);


class COMPASS : public SingletonTemplate<COMPASS>
{
	private:
		uint16_t iCompassDegree;
		uint16_t iBearing;
	public:
		COMPASS();
		void initializeCompass();
		uint16_t GetCompassDegree() { return iCompassDegree; }
		uint16_t GetCompassBearing() { return iBearing; }

		void updateCompassBearing(double dCurLatitude, double dCurLongitude, double dDestLatitude, double dDestLongitude);
};

#endif /* COMPASS_HPP_ */
