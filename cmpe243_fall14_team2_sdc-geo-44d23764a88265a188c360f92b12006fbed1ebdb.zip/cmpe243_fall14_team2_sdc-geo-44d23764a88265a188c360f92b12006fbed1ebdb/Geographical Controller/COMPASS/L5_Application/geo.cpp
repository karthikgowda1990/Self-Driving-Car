/*
 *  geo.cpp
 *  Created on: 11/1/2014
 *  Author: Harsh
 */

/*Adding new Comment*/

#include "boardIds.hpp"
#include "geo.hpp"

static volatile bool startBoard = false;
static volatile bool stopBoard = false;

static volatile bool waypointsReceived = false;

static volatile double waypointData[50][2] = { 0 };
static volatile int coordinateCounter = 0;

static volatile uint8_t data[8] = { 0 };

GEO& oGeo = GEO::getInstance();
GPS& oGPS = GPS::getInstance();
COMPASS oCompass = COMPASS::getInstance();

void TestCoordinateForAndroid();
void DebugWait();

canDataSendTask::canDataSendTask(uint16_t periodMs, uint8_t priority,
        const char* taskName, uint32_t stackSize) :
        scheduler_task(taskName, stackSize, priority), mTaskPeriodMs(periodMs), mCanDatasize(0)
{
    setRunDuration(periodMs);
}

void canMsgRecieveTask::logCANMessageRecieve()
{
    static bool oldLEDValue = false;

    // All controllers: Led2 toggles upon Rx
    if (oldLEDValue == false)
        LE.on(2);
	else
        LE.off(2);

    oldLEDValue = !oldLEDValue;

    uint16_t canmsgDropCount = CAN_get_rx_dropped_count(can1);
    /*if(canmsgDropCount)
     {
     LD.setNumber(canmsgDropCount);
     }*/
    if (canmsgDropCount)
        LE.on(4);
	else
        LE.off(4);
}

void canDataSendTask::logCANMessageTransmit()
{
    static uint32_t canPreviousMsgCount = 0;
    static bool oldLEDValue = false;
    uint32_t msgCount = GetCanMsgCount();

    if (canPreviousMsgCount != msgCount)
    {
        // All controllers: Led3 toggles upon Tx
        if (oldLEDValue == false)
            LE.on(3);
		else
            LE.off(3);

		oldLEDValue = !oldLEDValue;
		canPreviousMsgCount=msgCount;
	}
}

    /* IN order to get compass data, we must first receive waypoints from android, otherwise we dont have anything to work with*/
bool canDataSendTask::run(void *p)
{
    if (startBoard && waypointsReceived)
    {
        memset(&mCanData, 0, sizeof(mCanData));

#ifdef DEBUG_GEO
        printf("canDataSendTask::run\n");
#endif

        //DebugWait();

        oCompass.initializeCompass();
        oGPS.initializeGPS();

        oGeo.updateCurrentDestination(oGPS.getLongitude(), oGPS.getLatitude());
        oCompass.updateCompassBearing(oGPS.getLatitude(), oGPS.getLongitude(), oGeo.getCurrentDestinationLatitude(), oGeo.getCurrentDestinationLongitude());
        //oCompass.updateCompassBearing(oGPS.getLatitude(), oGPS.getLongitude(), 37.335706, -121.881567);

        uint16_t* temp = (uint16_t*) mCanData;
        uint16_t compass = oCompass.GetCompassDegree();
        temp[0] = compass; //Add any offset (if required) here
        temp[1] = (!oGeo.getIsDestinationReached()) ? oCompass.GetCompassBearing() : CMD_DESTINATION_REACHED; // send 4000 to signal destination reached
        mCanDatasize = 4;
//#ifdef DEBUG_GEO
        printf("\nCompass: %d \nBearing: %d \n", temp[0], temp[1]);

        if (oGeo.getIsDestinationReached())
        {
            printf("\n***********************\nDEstination REached!!!! \n***********************\n");
            //delay_ms(10000); //REMOVE THIS LATER
            LD.setLeftDigit('E');
            LD.setRightDigit('D');
        }
//#endif

        LOG_INFO("%lf,%lf,%d,%d,%lf,%lf,%lf,%d,%d", oGPS.getLatitude(), oGPS.getLongitude(), oCompass.GetCompassDegree(), oCompass.GetCompassBearing(),
                   oGeo.getDistanceToFinalDestination(), oGeo.getCurrentDestinationLatitude(), oGeo.getCurrentDestinationLongitude(),
                   oGeo.getCurrentDestination(), oGeo.getFinalDestination());

        printf("%lf,%lf,%d,%d,%lf,%lf,%lf,%d,%d", oGPS.getLatitude(), oGPS.getLongitude(), oCompass.GetCompassDegree(), oCompass.GetCompassBearing(),
                           oGeo.getDistanceToFinalDestination(), oGeo.getCurrentDestinationLatitude(), oGeo.getCurrentDestinationLongitude(),
                           oGeo.getCurrentDestination(), oGeo.getFinalDestination());

        canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_geo_publish_getDisplayData), mCanData, mCanDatasize);
        canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_compass_publish_data), mCanData, mCanDatasize);
        logCANMessageTransmit();

        //DebugWait();

        /*printf("Android Latitude: %lf, Android Longitude: %lf\n", oGeo.getAndroidWaypointLatitudeInfo()[0], oGeo.getAndroidWaypointLongitudeInfo()[0]);
         printf("Current Latitude: %lf, Current Longitude: %lf\n", oGPS.getLatitude(), oGPS.getLongitude()); */
        // To Do: Log messages
    }
    return true;
}

static void subscription_add(can_msg_t* msg)
{
    if (msg == NULL)
        return;

    uint8_t srcId = ((*msg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (*msg).msg_id & 0xfffU | 0x00000100; //changing subscription message to subscribed message

#ifdef DEBUG_GEO
    printf("message id is: %x,src id is: %x\n ", (*msg).msg_id, srcId);
#endif

    msgRate_t msgRate = convertHzTomsdRateEnum((*msg).data.bytes[0]);
    canSubscribedMsgTask::addSubscribedMsg(msgRate, srcId, msgId, msg);
}

void displayCounter()
{
    // 2-digit LED display used for displaying count of total received coordinates from android phone

    if (oGeo.getReceivedLongitudeCount() >= 10)
        LD.setRightDigit('T');
    else
        LD.setRightDigit(oGeo.getReceivedLongitudeCount()+'0');

    if (oGeo.getReceivedLatitudeCount() >= 10)
        LD.setLeftDigit('T');
    else
        LD.setLeftDigit(oGeo.getReceivedLatitudeCount()+'0');
}

// In case Geo wants special, one-time data from some controller (0x3 series mid), the decoding of that received data will take place here
void extractWaypointData(can_msg_t& mmsg)
{
    uint8_t srcId = ((mmsg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (mmsg).msg_id & 0xfffU;
    double d_AndroidLogitudeEntry = 0.00;
    double d_AndroidLatitudeEntry = 0.00;
#ifdef DEBUG_GEO
    puts("GEO: CAN published message got from Android\n");
    // printf(" with message id:%x, %x and message data: %x,%x,%x,%x,%x,%x,%x,%x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU),mmsg.data.bytes[0],mmsg.data.bytes[1],mmsg.data.bytes[2],mmsg.data.bytes[3],mmsg.data.bytes[4],mmsg.data.bytes[5],mmsg.data.bytes[6],mmsg.data.bytes[7]);
#endif

    if (msgId == mid_andriod_controllercmd_gpsDestination_latitude)
    {
#ifdef DEBUG_GEO
        printf("Android Latitude received\n");
#endif
        memcpy((char *) &(d_AndroidLatitudeEntry), (char*) &(mmsg.data.qword), 8);

        oGeo.addAndroidLatitudeEntry(d_AndroidLatitudeEntry);
        printf("Android Latitude: %lf, d_AndroidLatitudeEntry: %lf\n Data Length: %d\n vector size: %d \n",
                oGeo.getAndroidWaypointLatitudeInfo()[oGeo.getReceivedLatitudeCount()-1], d_AndroidLatitudeEntry, mmsg.frame_fields.data_len, oGeo.getReceivedLatitudeCount());
    }
    else if (msgId == mid_andriod_controllercmd_gpsDestination_longitude)
    {
        memcpy((char *) &(d_AndroidLogitudeEntry), (char*) &(mmsg.data.qword), 8);

        oGeo.addAndroidLongitudeEntry(d_AndroidLogitudeEntry);
        printf("Android Longitude: %lf, d_AndroidLogitudeEntry: %lf\n Data Length: %d\n vector size: %d \n",
                oGeo.getAndroidWaypointLongitudeInfo()[oGeo.getReceivedLongitudeCount()-1], d_AndroidLogitudeEntry, mmsg.frame_fields.data_len, oGeo.getReceivedLongitudeCount());
    }
    else if (msgId == mid_andriod_controllercmd_gpsDestination_eom)
    {
        //TODO: check if all coordinates received are in order
        // In future we can work sending an acknowledgment
        printf("EOM Received \n");
        waypointsReceived = true;
        oGeo.setFinalDestination(); // set final destination once received all android coordinates

        std::cout << "EOM: Destination: " << oGeo.getDistanceToFinalDestination() << ", IsDestinationReached: " << oGeo.getIsDestinationReached() << std::endl;
        DebugWait();
    }

    displayCounter();
}

void readControllerSpecificData(can_msg_t& msg)
{
    uint8_t srcId = ((msg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (msg).msg_id & 0xfffU;

#ifdef DEBUG_GEO
    puts("COMPASS: CAN controller specific message got");
    printf(" with message id:%x, %x\n", (msg.msg_id), (msg.msg_id & 0xfffU));
#endif

    if (msgId == mid_master_controllercmd_start
            && srcId == cid_master_controller)
    {
#ifdef DEBUG_GEO
        printf("Master start data got \n");
#endif
        startBoard = true;
    }
    if ((msgId == mid_andriod_controllercmd_gpsDestination_latitude
            || msgId == mid_andriod_controllercmd_gpsDestination_longitude
            || msgId == mid_andriod_controllercmd_gpsDestination_eom)
            && srcId == cid_andriod_controller)
    {
        printf("Android start data got \n");
#ifdef DEBUG_GEO
        printf("Android start data got \n");
#endif

        // 11/16/2014 - Getting android data
        extractWaypointData(msg);
    }
    //For Test using Sample Co-ordinates
    //	TestCoordinateForAndroid();
    //	printf("TestCoordinateForAndroid: vector size: %d", oGeo.getReceivedCoordinateCount());
}

void readSubscribedData(can_msg_t& mmsg)
{
    can_msg_t* msg = new can_msg_t;

    if (msg == NULL)
        return;

#ifdef DEBUG_GEO
    puts("GEO: CAN subscription message got");
    printf(" with message id:%x, %x\n", (mmsg.msg_id), (mmsg.msg_id & 0xfffU));
#endif
    memset(msg, 0, sizeof(msg));
    *msg = mmsg;
    subscription_add(msg);
}

/*In case Geo subscribes for regular updates for some controller data, the decoding of that received data will take place here (0x5 series mid)*/
void readPublishedData(can_msg_t& mmsg)
{
    uint8_t srcId = ((mmsg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (mmsg).msg_id & 0xfffU;
#ifdef DEBUG_GEO
    puts("GEO: CAN published message got \n");
    // printf(" with message id:%x, %x and message data: %x,%x,%x,%x,%x,%x,%x,%x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU),mmsg.data.bytes[0],mmsg.data.bytes[1],mmsg.data.bytes[2],mmsg.data.bytes[3],mmsg.data.bytes[4],mmsg.data.bytes[5],mmsg.data.bytes[6],mmsg.data.bytes[7]);
#endif

    if (msgId == mid_sensor_publish_data && srcId == cid_sensor_controller)
    {
#ifdef DEBUG_GEO
        printf("sensor data got \n");
#endif
        data[0] = mmsg.data.bytes[0];
        data[1] = mmsg.data.bytes[1];
        data[2] = mmsg.data.bytes[2];
        data[3] = mmsg.data.bytes[3];
        data[4] = mmsg.data.bytes[4];
        data[5] = mmsg.data.bytes[5];
        data[6] = mmsg.data.bytes[6];
        data[7] = mmsg.data.bytes[7];
    }
}

canMsgRecieveTask::canMsgRecieveTask(uint16_t periodMs, uint8_t priority,
        const char* taskName, uint32_t stackSize) :
        scheduler_task(taskName, stackSize, priority), mTaskPeriodMs(periodMs)
{
    setRunDuration(periodMs);
}

bool canMsgRecieveTask::run(void *p)
{
#ifdef DEBUG_GEO
    printf("Task running\n");
#endif
    if (CAN_rx(can1, &mmsg, portMAX_DELAY))
    {
#ifdef DEBUG_GEO
        printf("Msg received\n");
        puts("MASTER: CAN subscription message got\n");
#endif
        logCANMessageRecieve();

        switch (mmsg.msg_id & (0xfffU))
        {
            case 0x300 ... 0x3FF:
            {
                readControllerSpecificData(mmsg);
            }
                break;
            case 0x400 ... 0x4FF:
            {
                readSubscribedData(mmsg);
            }
                break;
            case 0x500 ... 0x5FF:
            {
                readPublishedData(mmsg);
            }
                break;
            default:
#ifdef DEBUG_GEO
                printf("MASTER: Unexpected message id got(geo):%x, %x\n", (mmsg.msg_id), (mmsg.msg_id & 0xfffU));
#endif
                break;
        };
    }
    return true;
}

void GEO::updateCurrentDestination(double dCurrentLongitude,
        double dCurrentLatitude)
{
    double dDistanceToCurrentDestination = 0.00;

    dDistanceToCurrentDestination = ComputeDistanceM(dCurrentLatitude, dCurrentLongitude, this->getCurrentDestinationLatitude(), this->getCurrentDestinationLongitude());
    printf("\n Distance to current destination: %lf", dDistanceToCurrentDestination);
    if (dDistanceToCurrentDestination <= ALLOWED_DIST_TOLERANCE)
    {
        iCurrentDestination++;
        printf("\n***********************\nOne coordinate down!!!! \n***********************\n");
        printf("\n*****\n Lat reached : %f\n******\n Long reached: %f", this->getCurrentDestinationLatitude(), this->getCurrentDestinationLongitude());
        LD.setLeftDigit('O');
        LD.setRightDigit('D');
    }

    isDestinationReached = ((iCurrentDestination > iFinalDestination) && iFinalDestination != 0) ? true : false;

    //DebugWait();
}

// Calculate haversine distance from http://stackoverflow.com/a/1416950
// Ex. takes latitude and longitude in 37.336657,-121.881748 (decimal degrees) only
double GEO::ComputeDistanceM(double lat1, double long1, double lat2, double long2)
{
    const double R = 6372.797560856;
    const double d2r = (M_PI / 180.0);
    const double r2d = (180.0 / M_PI);

    double dlong = (long2 - long1) * d2r;
    double dlat = (lat2 - lat1) * d2r;
    double a = pow(sin(dlat / 2.0), 2)
            + cos(lat1 * d2r) * cos(lat2 * d2r) * pow(sin(dlong / 2.0), 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double dDistance = R * c * 1000.0;

    printf("ComputeDistanceM - lat1: %lf, long1: %lf, lat2: %lf, long2: %lf\n", lat1, long1, lat2, long2);
    //std::cout << "ComputeDistanceM - lat1: " << lat1 << ", long1: " << long1 << ", lat2: " << lat2 << ", long2: " << long2 << std::endl;
    std::cout << "ComputeDistanceM - Distance: " << dDistance << std::endl;

    return dDistance;
}

void TestCoordinateForAndroid()
{
    // sample coordinate near by engineering building 7th street parking,
    // (1) 37.337089, -121.882599
    // (2) 37.336726, -121.882352
    // (3) 37.336562, -121.882645		(right turn)
    oGeo.addAndroidLatitudeEntry(37.337089);
    oGeo.addAndroidLongitudeEntry(-121.882599);

    oGeo.addAndroidLatitudeEntry(37.336726);
    oGeo.addAndroidLongitudeEntry(-121.882352);

    oGeo.addAndroidLatitudeEntry(37.336562);
    oGeo.addAndroidLongitudeEntry(-121.882645);
}

// use this function as breakpoint during debugging, only during testing
void DebugWait()
{
//    bool bTestSwitch = false;
//    while (!bTestSwitch)
//    {
//        bTestSwitch = (!bTestSwitch) ? SW.getSwitch(1) : bTestSwitch;
//        delay_ms(20);
//        if(bTestSwitch) break;
//    }
}
