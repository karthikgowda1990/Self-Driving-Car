/*
 * ErrCodes.h
 *
 *  Created on: Oct 11, 2014
 *      Author: h.siyamwala
 */

#ifndef ERRCODES_H_
#define ERRCODES_H_

/// All Error codes goes here
/// For instance
typedef enum MASTER_ERROR_CODE{
    MASTER_TIMEOUT=0x80000000,
    MASTER_FAILED_GETTING_DATA,
} MASTER_ERROR_CODE;
typedef enum SENSOR_ERROR_CODE{
    SENSOR_FAILURE=0x81000000,
} SENSOR_ERROR_CODE;

typedef enum GPS_COMPASS_ERROR_CODE{
    GPS_FAILURE=0x82000000,
} GPS_COMPASS_ERROR_CODE;

#endif /* ERRCODES_H_ */
