Note:
______________________________________________________
This directory contains firwares which will connect the PC USB port (Hercules.exe) to the GPS, so that configuration commands can be sent to it. The SJ One Board should be connected to PC USB port (Hercules.exe) . The SJ One Board should be connected to the GPS over UART2. Following firmwares are to be burnt on a SJ One Board.


*1.	lpc1758_freertos_GPS_BOTH_115200.hex
Use this firmware, if the GPS is already configured at 115200 bps.
Note, this firmware communicates with PC USB port (Hercules.exe) at 115200 bps.




*2.	lpc1758_freertos_GPS_9600.hex
Use this firmware for NEW GPS. Since, the new GPS will communiv=csate at 9600bps.Note, this firmware communicates with PC serial port (Hercules.exe) at 38400 bps.



Updated: 11/26/2014 Yash Parulekar
______________________________________________________
A few handy GPS commands for the Venus GPS. these commands were refered from Application Note AN0003.pdf i.e. "Binary Messages Of
SkyTraq Venus 6 GPS Receiver Ver 1.4.19". Following commands will update the data flash:
1. CONFIGURE NMEA MESSAGE to send GGA and RMC NMEA sentences:
A0 A1 00 09 08 01 00 00 00 01 00 00 01 09 0D 0A

2. CONFIGURE SERIAL PORT and change to 115200:
A0 A1 00 04 05 00 05 01 01 0D 0A

3. change rate to 10Hz  //CONFIGURE SYSTEM POSITION RATE:
A0 A1 00 03 0E 0A 01 05 0D 0A

Updated: 11/12/2014 Yash Parulekar
______________________________________________________