/*
 * gps.cpp
 *
 *  Created on: Oct 12, 2014
 *      Author: YashParulekar-Toshiba
 *      Contact: yash.parulekar@sjsu.edu
 */

#include "gps.hpp"


gpsTask::gpsTask(UartDev& uartForGps, uint8_t priority) :
scheduler_task("gps", 512*8, priority),
mGps(uartForGps),
mGpsBaudRate(GPS_BAUD_RATE)
{
    ;
}

bool gpsTask::run(void *p){
    return true;
}
/*
 * Documentation:
 * PRIMARY GOAL:
 * 1)Run GPS in default mode:
 * a)Format: WGS-84
 * b)Update rate: 1Hz
 * 2)Transmit on CAN running at 10Hz although the OG rate is 1Hz.
 * SECONDARY GOAL:
 * 1) upgrade to 10 Hz, change format: change format to GGA and upgrade baud rate if necessary
 * TERTIARY GOAL:
 * 1) Look into GPS pinning mode and
 * Create 10Hz task
 * */
