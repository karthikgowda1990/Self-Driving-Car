/*
 * gps.hpp
 *
 *  Created on: Oct 21, 2014
 *      Author: YashParulekar-Toshiba
 *      Contact: yash.parulekar@sjsu.edu
 */
/*
 * Description: UART drivers for GPS module :Venus GPS
 * GPS Module Properties:
 * Firmware version: ??? to do yash update
 * Interface UART*/
#ifndef GPS_HPP_
#define GPS_HPP_

#include "uart_dev.hpp"
#include "scheduler_task.hpp"

#define GPS_BAUD_RATE 9600 //default for Venus GPS

//Class for GPS task

class gpsTask : public scheduler_task
{
public:
        //Constructor
        gpsTask(UartDev& uartForGps, uint8_t priority);

        bool run(void *p);    ///< Fetches data from UART
        bool init(void);
 //       bool taskEntry(void); ///< Auto-detects baud-rate and sets it to GPS

private:
        UartDev& mGps;               ///< The uart to use for Venus GPS
        uint32_t mGpsBaudRate;       ///< The baud rate of the GPS

};





#endif /* GPS_HPP_ */
