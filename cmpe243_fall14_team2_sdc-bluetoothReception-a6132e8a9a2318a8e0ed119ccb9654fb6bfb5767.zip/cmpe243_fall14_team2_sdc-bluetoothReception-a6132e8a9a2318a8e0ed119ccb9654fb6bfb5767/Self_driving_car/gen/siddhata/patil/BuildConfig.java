/** Automatically generated file. DO NOT MODIFY */
package siddhata.patil;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}