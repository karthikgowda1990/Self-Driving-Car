#include "uart2.hpp"       // Board sensors
#include "io.hpp"
#include <string.h>
#include "utilities.h"  // delay_ms()
#include<stdio.h>
#include<string.h>


char uart1_pchar(char out)
{
   LPC_UART2->THR = out;
   while(! (LPC_UART2->LSR & (1 << 6)));
   return 1;
}

char uart1_gchar(char &in)
{
    while(! (LPC_UART2->LSR & (1 << 0)));
    in=LPC_UART2->RBR;

    return 1;
}

int main(void)
{
            LPC_SC->PCONP|=(1<<24);
            LPC_SC->PCLKSEL1 &= ~(3<<16);
            LPC_SC->PCLKSEL1 |= (1<<16);

            LPC_PINCON->PINSEL4 &= ~(3<<16);
            LPC_PINCON->PINSEL4 |= (1<<17);
            LPC_PINCON->PINSEL4 &= ~(3<<18);
            LPC_PINCON->PINSEL4 |= (1<<19);

            LPC_UART2->LCR |= (1 << 7);
            uint32_t d=(sys_get_cpu_clock())/ ((16 * 9600) + 0.5);
            LPC_UART2->DLM = (d >> 8);
            LPC_UART2->DLL = d;
            LPC_UART2->LCR &= ~(1 << 7);
            LPC_UART2->LCR |= (3<<0);

            LPC_PINCON->PINSEL0 &= ~(3<<0);
            LPC_GPIO0->FIODIR |=(1<<0);
            LPC_GPIO0->FIOSET= 0x01;

            char *a="AT+STATE?\r\np";
            char C=a[0];
            char m[20];
            int i=0;

                    while(1)
                    {
                            uart1_gchar(C);
                            printf("%c\n",C);
                    }



    return -1;
}
