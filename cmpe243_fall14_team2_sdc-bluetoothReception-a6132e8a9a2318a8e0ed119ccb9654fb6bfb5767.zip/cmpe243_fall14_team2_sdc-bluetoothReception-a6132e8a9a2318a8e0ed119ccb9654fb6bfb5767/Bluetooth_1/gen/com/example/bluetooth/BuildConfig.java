/** Automatically generated file. DO NOT MODIFY */
package com.example.bluetooth;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}