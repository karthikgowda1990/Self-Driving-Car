/*
 * motor.hpp
 *
 *  Created on: Oct 13, 2014
 *      Author: Pradyumna Upadhya
 */

#ifndef MOTOR_HPP_
#define MOTOR_HPP_
#include "printf_lib.h"
#include <stdio.h>
#include<iostream>
#include <stdint.h>
#include "subscription_task.hpp"
#include "scheduler_task.hpp"
#include "io.hpp"
#include <string.h>
#include "utilities.h"
#include "soft_timer.hpp"
#include "command_handler.hpp"
#include "wireless.h"
#include "char_dev.hpp"
#include "FreeRTOS.h"
#include "semphr.h"
#include "subscription_task.hpp"
  class canDataSendTask : public scheduler_task
    {
        public:
           canDataSendTask(uint16_t periodMs, uint8_t priority,const char* taskName,uint32_t stackSize);

            bool run(void *p);

        private:
            const uint16_t mTaskPeriodMs;
            uint8_t mCanData[8];
            uint8_t mCanDatasize;
            can_msg_t mCanMsg;
            void logCANMessageTransmit();

    };




static void  subscription_add(can_msg_t* msg);


class canMsgRecieveTask : public scheduler_task
   {
       public:
           canMsgRecieveTask(uint16_t periodMs,uint8_t priority,const char* taskName,uint32_t stackSize);

           bool run(void *p);

       private:
           const uint16_t mTaskPeriodMs;
           can_msg_t mmsg;

           void logCANMessageRecieve();
   };




 bool GetMotorData(uint8_t *const canDataArray,uint8_t& dataSize);

 //TODO:  Add definitions for these functions.

 motor_direction_t GetMotorDirection();
 motor_speed_t GetMotorSpeed();

 bool SetMotors(const motor_direction_t& motorDir,const motor_speed_t& motorSpeed);

 bool SetFrontMotor(const motor_direction_t& motorDir);

 bool SetBackMotor(const motor_speed_t& motorSpeed);
 void swisr();
#endif /* MOTOR_HPP_ */
