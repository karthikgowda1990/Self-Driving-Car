/*
 * motor.cpp
 *
 *  Created on: Oct 13, 2014
 *      Author: Pradyumna Upadhya
 */

#include "boardIds.hpp"
#include "motor.hpp"

#include "uart2.hpp"     //M#include "lpc_pwm.hpp"   //M#include "gpio.hpp"      //M
int curr_distance = 0;
static volatile uint8_t motor_data[8] =
{ 0 };
static volatile bool startBoard = false;
static volatile bool stopBoard = false;
static volatile int count = 0;
static volatile int turn_count = 0;
static volatile int last_turn = 0;
static volatile bool light= false;
bool MotorDataProcessing(int, float, float, int);

canDataSendTask::canDataSendTask(uint16_t periodMs, uint8_t priority,
        const char* taskName, uint32_t stackSize) :
        scheduler_task(taskName, stackSize, priority), mTaskPeriodMs(periodMs), mCanDatasize(
                0)
{
    setRunDuration(periodMs);
}

bool canDataSendTask::run(void *p)
{

//    if(SW.getSwitch(1))
//    {
//    //puts("Publish Dummy Data by calling PublishSubscribedMessageData\n");
//
//     memset(&mCanData, 0, sizeof(mCanData));
//
//     mCanData[0]= static_cast<uint8_t>(GetMotorSpeed());
//     mCanDatasize=1;
//
//     return canSubscribedMsgTask::PublishSubscribedMessageData(static_cast<uint16_t>(mid_motor_subscribe_motorSpeed),mCanData,mCanDatasize);
//     }

    if (startBoard == true && count < 5)
    {
        printf("count:%d\n", count);
        puts("Sending CAN subscription message to master\n");

        memset(&mCanMsg, 0, sizeof(mCanMsg));
        memset(&mCanData, 0, sizeof(mCanData));
        mCanData[0] = 5;
        mCanDatasize = 1;
        mCanMsg = CreateCANMessage(0, 0x0505242A, 1, 1, (const char*) mCanData);
        CAN_tx(can1, &mCanMsg, 0);
        //stopBoard == false;
        count++;

    }
    logCANMessageTransmit();

    return true;
}

static void subscription_add(can_msg_t* msg)
{
    if (msg == NULL)
        return;

    uint8_t srcId = ((*msg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = ((*msg).msg_id & 0xfffU) | 0x00000100; //changing subscription message to subscribed message

#ifdef DEBUG_SUBSCRIPTION_TASK
    printf("message id is: %x,src id is: %x\n ", (*msg).msg_id, srcId);
#endif

    msgRate_t msgRate = convertHzTomsdRateEnum((*msg).data.bytes[0]);
    canSubscribedMsgTask::addSubscribedMsg(msgRate, srcId, msgId, msg);

}

canMsgRecieveTask::canMsgRecieveTask(uint16_t periodMs, uint8_t priority,
        const char* taskName, const uint32_t stackSize) :
        scheduler_task(taskName, stackSize, priority), mTaskPeriodMs(periodMs)
{
    setRunDuration(periodMs);
    MotorDataProcessing((int)motor_state_update,(1500/100.0),(1500/100.0),10);
}

void canMsgRecieveTask::logCANMessageRecieve()
{
    static bool oldLEDValue = false;

    if (oldLEDValue == false)
        LE.on(2);
        else
        LE.off(2);

    oldLEDValue = !oldLEDValue;
}

void canDataSendTask::logCANMessageTransmit()
{
    static uint32_t canPreviousMsgCount = 0;
    static bool oldLEDValue = false;
    uint32_t msgCount = GetCanMsgCount();

    if (canPreviousMsgCount != msgCount)
    {

        if (oldLEDValue == false)
        {
            LE.on(3);
        }
        else
        LE.off(3);

        oldLEDValue = !oldLEDValue;

    }
    canPreviousMsgCount = msgCount;
}

void rec_data(can_msg_t& msg)
{
    uint8_t srcId = ((msg).msg_id >> CAN_MESSAGEBITS) & (0xffU);
    uint16_t msgId = (msg).msg_id & 0xfffU;

    if (msgId == mid_master_controllercmd_start
            && srcId == cid_master_controller)
    {
#ifdef DEBUG_SUBSCRIPTION_TASK
        printf("Master start data got \n");
#endif
        startBoard = true;
        stopBoard = false;
        LE.on(1);
        delay_ms(100);
        count = 0;
    }

    if (msgId == mid_master_controllercmd_stop
            && srcId == cid_master_controller)
    {
#ifdef DEBUG_SUBSCRIPTION_TASK
        printf("Master start data got:%d \n", stopBoard);
#endif
        stopBoard = true;
        startBoard = false;
        count = 0;
    }

}

bool b = 0;
void swisr()
{
    {
        b = b ^ 1;
        if (b == 0)
        {
            LE.on(4);
        }
        else
        {
            LE.off(4);
        }
        count++;
    }
}

bool canMsgRecieveTask::run(void *p)
{

    if (CAN_rx(can1, &mmsg, portMAX_DELAY))
    {
        logCANMessageRecieve();


        switch (mmsg.msg_id & (0xfffU))
        {
            case 0x300 ... 0x3FF:
                rec_data(mmsg);
                if (stopBoard == true || startBoard == true)
                {
                    uint16_t speed = 1500;
                    uint16_t dir = 1500;
                    uint16_t distance = 0;
                    MotorDataProcessing((int) mmsg.data.bytes[0], (dir / 100.0),
                            (speed / 100.0), (int) distance);
                    LE.off(1);
                }
                break;

#if 0
                case 0x400 ... 0x4FF:
#ifdef DEBUG_SUBSCRIPTION_TASK
                puts("MOTOR: CAN subscription message got.");
                printf(" with message id:%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
                memset(msg, 0, sizeof(msg));
                *msg=mmsg;
                subscription_add(msg);
                break;
#endif

                case 0x500 ... 0x5FF:
                { //published data got...
                  //call functions like setmotordata() here


                    LPC_GPIO1->FIODIR |=(0x1b<<19);
                    uint16_t speed = 1500;
                    uint16_t dir = 1500;
                    uint16_t distance = 0;
                    uint16_t* temp=(uint16_t*)&mmsg.data.bytes[motor_dataIndex_speed];
                    speed=*temp;
                    temp=(uint16_t*)&mmsg.data.bytes[motor_dataIndex_direction];
                    dir=*temp;
                    temp= (uint16_t*)&mmsg.data.bytes[motor_dataIndex_distance];
                    distance=*temp;

                  //  LPC_GPIO1->FIOPIN|=(0x1b<<19);

                    if(dir==1500)
                    {
                        light= light^1;
                       // light=1;
                       // LPC_GPIO1->FIOPIN &=~(3<<19);
                       // LPC_GPIO1->FIOPIN &=~(3<<22);

                        if(light)
                        LPC_GPIO1->FIOPIN |=(0x1b<<19);
                        else
                        LPC_GPIO1->FIOPIN &=~(0x1b<<19);

                    }
                    else
                    {

                        light=true;
                        LPC_GPIO1->FIOPIN |=(0x1b<<19);

                    }



                    if(stopBoard==false)

                    {
                         if (dir==last_turn  )
                         {
                             turn_count++;

                         }
                         else
                         {
                             turn_count=0;

                         }
                         if (turn_count<50)
                          MotorDataProcessing((int)motor_state_update,(dir/100.0),(speed/100.0),(int)distance);
                         else
                         {   int i=1000;
                             int turn_value= dir>1500?(-500):(500);
                             while(i--)

                             { MotorDataProcessing((int)motor_state_update,(1500/100.0),(1500/100.0),10);}

                             MotorDataProcessing((int)motor_state_update,((dir+turn_value)/100.0),(1275/100.0),10);
                         }
                    }
                    last_turn=dir;
                    printf("message id:%x, %x length: %d,%d,%d\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU),dir,speed,distance);

#ifdef DEBUG_SUBSCRIPTION_TASK
                    // puts("MASTER: CAN subscribed message got");
                    //  printf(" with message id:%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
                }
                break;

                default:
                //delete msg;
#ifdef DEBUG_SUBSCRIPTION_TASK
                printf("Unexpected message id got(master):%x, %x\n",(mmsg.msg_id),(mmsg.msg_id&0xfffU) );
#endif
                break;
            };

    }

    return true;
}

bool GetMotorData(uint8_t * const canDataArray, uint8_t& dataSize)
{

#ifdef DEBUG_SUBSCRIPTION_TASK
    //puts("MOTOR:Inside GetMotorSpeedData\n");
#endif

    //adding dummy speed data.
    canDataArray[0] = 10; //NOTE: we have to discuss data format
    dataSize = 1;

    return true;
}

motor_speed_t GetMotorSpeed()
{

    //TODO: ADD  the calculations here...
    return motor_speed_15p0;

}

bool MotorDataProcessing(int motor_dataIndex_state,
        float motor_dataIndex_direction, float motor_dataIndex_speed,
        int motor_dataIndex_distance)
{
    PWM pwm1(PWM::pwm1, 100); //M Pwm1: PIN 2.0 , 100 Hz (10 ms ) Back Motor
    PWM pwm2(PWM::pwm2, 100); //M Pwm1: PIN 2.2 , 100 Hz (10 ms ) Front Motor

    switch (motor_dataIndex_state)
    {
        case motor_state_continue:
            if (curr_distance == 0)
            {
                break;
            }
            curr_distance--;
            pwm1.set(motor_dataIndex_speed); // Main Motor reverse
            pwm2.set(motor_dataIndex_direction); // Front motor Neutral
            delay_ms(100);
            break;
        case motor_state_update:
            curr_distance = motor_dataIndex_distance;
            pwm1.set(motor_dataIndex_speed); // Main Motor reverse
            pwm2.set(motor_dataIndex_direction); // Front motor Neutral
            break;
        case motor_state_deaccelerate:
            pwm1.set(motor_dataIndex_speed); // Main Motor reverse
            pwm2.set(motor_dataIndex_direction); // Front motor Neutral
            delay_ms(500);
            pwm1.set(motor_dataIndex_speed); // Main Motor  Neutral
            pwm2.set(motor_dataIndex_direction); // Front motor Neutral
            break;
        default:
            pwm1.set(motor_dataIndex_speed); // Main Motor  Neutral
            pwm2.set(motor_dataIndex_direction); // Front motor Neutral
            break;
    }

    //TODO: ADD  the calculations here...
    return 1;

}

//bool motor_deaccer(
//        int motor_dataIndex_speed) // car stopping algorithm is based to stop the car
//                                  //                  at any speed for the same stopping distance
//{ /*int delay=600;                  // the delay of each case would be reduced by calibration
//    int i=( motor_dataIndex_speed-15);
//     int k;
//
//    for (k=i;k=0;k--)
//    {pwm1.set(15-i);  reverse 20 %
//        delay_ms(delay/i);}*/
//
//    if(motor_dataIndex_speed_f60)
//    {   pwm1.set(motor_speed_b20)//pwm1.set(14);  reverse 20 %
//        delay_ms(600);
//    pwm1.set(motor_speed_b0)//pwm1.set(15);        neutral
//    }
//
//    else if(motor_dataIndex_speed_f40)
//        {   pwm1.set(motor_speed_b40)//pwm1.set(13);  reverse 40 %
//                    delay_ms(300);
//        pwm1.set(motor_speed_b20)//pwm1.set(14);  reverse 20 %
//                   delay_ms(300);
//        pwm1.set(motor_speed_b0)//pwm1.set(15);        neutral
//        }
//
//    else if(motor_dataIndex_speed_f60)
//     {    pwm1.set(motor_speed_b60)//pwm1.set(12);  reverse 60 %
//        delay_ms(200);
//        pwm1.set(motor_speed_b40)//pwm1.set(13);  reverse 40 %
//                delay_ms(200);
//            pwm1.set(motor_speed_b20)//pwm1.set(14);  reverse 20 %
//                       delay_ms(200);
//            pwm1.set(motor_speed_b0)//pwm1.set(15);        neutral
//            }
//
//    else if(motor_dataIndex_speed_f80)
//       { pwm1.set(motor_speed_b80)//pwm1.set(11);  reverse 80 %
//        delay_ms(150);
//        pwm1.set(motor_speed_b60)//pwm1.set(12);  reverse 60 %
//            delay_ms(150);
//            pwm1.set(motor_speed_b40)//pwm1.set(13);  reverse 40 %
//                    delay_ms(150);
//                pwm1.set(motor_speed_b20)//pwm1.set(14);  reverse 20 %
//                           delay_ms(150);
//                pwm1.set(motor_speed_b0)//pwm1.set(15);        neutral
//                }
//
//
//    else if(motor_dataIndex_speed_f100)
//       {pwm1.set(motor_speed_b100)//pwm1.set(11);  reverse 100 %
//        delay_ms(120);
//        pwm1.set(motor_speed_b80)//pwm1.set(11);  reverse 80 %
//        delay_ms(120);
//        pwm1.set(motor_speed_b60)//pwm1.set(12);  reverse 60 %
//            delay_ms(120);
//            pwm1.set(motor_speed_b40)//pwm1.set(13);  reverse 40 %
//                    delay_ms(120);
//                pwm1.set(motor_speed_b20)//pwm1.set(14);  reverse 20 %
//                           delay_ms(120);
//                pwm1.set(motor_speed_b0)//pwm1.set(15);        neutral
//                }
//
//}
//}
