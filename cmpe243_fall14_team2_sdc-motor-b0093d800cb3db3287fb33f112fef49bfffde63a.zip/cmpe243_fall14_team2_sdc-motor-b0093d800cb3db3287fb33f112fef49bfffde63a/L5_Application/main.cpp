/*
 *     SocialLedge.com - Copyright (C) 2013
 *
 *     This file is part of free software framework for embedded processors.
 *     You can use it and/or distribute it as long as this copyright header
 *     remains unmodified.  The code is free for personal use and requires
 *     permission to use in a commercial product.
 *
 *      THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 *      OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 *      MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 *      I SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
 *      CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *     You can reach the author of this software at :
 *          p r e e t . w i k i @ g m a i l . c o m
 */

/**
 * @file
 * @brief This is the application entry point.
 */

#include <stdio.h>
#include<iostream>
#include<ssp1.h>
#include<can.h>
#include "utilities.h"
#include "printf_lib.h"
#include "string.h"
#include "tasks.hpp"
#include "str.hpp"
#include "examples/examples.hpp"
#include "io.hpp"
#include "subscription_task.hpp"
#include "motor.hpp"
#include "lpc_pwm.hpp"
#include "eint.h"

int main(void)
{

    LPC_GPIO1->FIODIR |=(0x1b<<19);
    LPC_GPIO1->FIOPIN|=(0x1b<<19);


    InitializeCan();
    eint3_enable_port2(7, eint_falling_edge, swisr);
    //setup CAN message id for switch on and switch off

    SetCANFilter(MOTOR_CAN29_EXGRP1START,MOTOR_CAN29_EXGRP1END);

    scheduler_add_task(new terminalTask(PRIORITY_HIGH));

    addSubscriptionTasks(PRIORITY_MEDIUM);

    // TODO: Move this to separate task that will have APIs for setSteer() and setWheels()
    PWM pwm1(PWM::pwm1, 100);
    PWM pwm2(PWM::pwm2, 100);

    delay_ms(1000);
    scheduler_add_task(new canMsgRecieveTask  (10,PRIORITY_MEDIUM,"CanMsgRecieveTask",4*512));
    scheduler_add_task(new canDataSendTask  (20,PRIORITY_MEDIUM,"canMsgSendTask",3*512));

    scheduler_start();


    return 0;
}
